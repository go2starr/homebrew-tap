# ghosh TODOs

## ~~Always-fresh sessions + in-process reconnect~~ (done 2026-06-12)
- Cross-invocation session cache (`~/.ghosh/sessions/cache-*`) removed.
  Every `ghosh user@host` now bootstraps a fresh daemon via ssh — old
  daemon is orphaned, pruned by next bootstrap. No more "two clients
  share one shell" surprise.
- In-process reconnect: a `SessionEnd` enum splits "terminal" (shell
  exited / Ctrl-Q / server clean close) from "transient" (QUIC dropped).
  On transient end, `main` calls `attach()` again with the in-memory
  `SessionInfo` (single retry, RECONNECT_TIMEOUT=3s). Whole task graph
  is respawned around the new connection inside `run_session_once`.
  Snapshot arrives and resets replica + prediction engine cleanly.
  Verified: SIGKILL daemon → "connection lost; reconnecting..." →
  "reconnect failed: attach timed out" → clean exit (~3s).
- Input seq counter is an `Arc<AtomicU64>` that survives reconnects so
  the server's monotonic input_seq stays ordered across the gap.

## ~~Scrollback sync~~ (done 2026-06-12, PROTO_VERSION 1→2)
Server keeps last 2000 history rows in ghosh-vt (`max_scrollback`).
Snapshot carries only the DELTA scrolled past since the previous attach
(`scrollback_at_last_attach` integer; `scrollback_vt_tail(new_lines)`).
Client temporarily exits alt-screen on snapshot, dumps the bytes (with a
trailing newline guard), re-enters alt-screen, then repaints — so the
dump lands in the HOST terminal's natural scrollback buffer instead of
needing a client-side viewer. Empty scrollback skips the alt-screen
dance entirely so first attach behaves exactly like v1. Verified e2e on
loopback AND wifi to mikes-macbook-pro: first reattach shows 8 lines
(grid overflow), second reattach no-dup (0 new), third reattach after
20 more lines adds 12 more. Reflow on resize: punted — existing lines
stay as-produced.

## ~~Per-host config~~ (done 2026-06-12)
`~/.ghosh/config`: trivial INI parser, no dep. `[<host>]` sections
+ `[defaults]` fallback, keys `server_cmd` and `ssh`. Env vars still
win over config. Example: dropping `server_cmd = /Users/mike/.local/...`
in the `[mike@mikes-macbook-pro]` section lets `ghosh mike@mikes-macbook-pro`
work without any env vars.

## ~~Orphan session-dir cleanup~~ (done 2026-06-12)
Daemon writes its pid into `~/.ghosh/sessions/<id>/pid` on startup.
SIGTERM handler removes the dir before exit. SIGKILL still leaks (no
handler possible), but next `--bootstrap` runs `prune_dead_sessions`
first, which scans for pid files whose process isn't alive
(`kill(pid, 0)`). EPERM counts as live so we never prune root-owned
processes the test user can't signal. Cache files (non-dirs) are
skipped so the client's `cache-host` entries are safe.

## ~~Roaming: QUIC migration validated~~ (done 2026-06-12)
GHOSH_ROAM=1 enables Ctrl-R as a `Endpoint::rebind` hook (filters the byte
out so the shell doesn't see it). Tested: 1 roam on loopback + 4 roams in
quick succession over wifi to mikes-macbook-pro during streaming output,
all input/output kept flowing. Quinn's default `migration=true` server +
client `rebind()` is sufficient — no extra config needed. Server log only
shows the original attach address (`client attached from ...`); migrated
paths aren't logged, but traffic continues. If needed later, add a hook on
`Connection::remote_address` change to log path migrations.

## ~~Prediction: real-link validation~~ (done 2026-06-12)
Validated against mikes-macbook-pro over wifi: adaptive ramp engaged
(display=On after 5 confirms, RTT 17–43ms — link was faster than the
historic 180ms since the laptop was awake/active), 20/20 confirms, ~45ms
avg echo, detach/reattach restored screen, fresh engine re-ramped after
reattach. Deploy gotcha: overwriting a binary in place on the remote Mac
gets the new copy SIGKILLed by AMFI (stale code-sign cache) — `rm` the
old file first so scp creates a fresh inode. Still untested in anger:
glitch underline + misprediction recovery under real loss/high RTT (wifi
power-save naps) — observe during daily use. Tuning knobs in predict.rs:
MIN_RTT_TO_DISPLAY (40ms), HITS_TO_DISPLAY (5), EXPIRY (1s), GLITCH (250ms).

## Prediction: known rough edges (revisit after real-link use)
- Bare updates (input_seq/cursor-only) aren't retransmitted on loss.
- cell_char is ASCII-oriented: wide glyphs upstream of a predicted cell
  misalign the comparison → false mispredict (safe direction).
- Speculative paint drops cell styling (plain glyph until echo).
- CR / word-erase / kill-line unmodeled; they just blank the cursor.

## ~~Incremental Modes/Title sync~~ (done 2026-06-12)
Shipped: `ObjId::{Modes,Title}`, structured `Modes` payload (postcard, not
VT passthrough — client forwards input-encoding modes to the host tty but
keeps alt_screen engine-only), title+modes in Snapshot, `ObjectSync`
generalized to `ObjId`-keyed map. PROTO_VERSION 0→1 — redeploy both
machines before the next two-machine test. E2E: title via tmux pane_title,
bracketed-paste set/reset via paste round-trip, title restore on reattach.

## Scrollback sync (v2)
Replica only mirrors the live grid; client scrollback is whatever was
rendered while attached, reattach = empty history.

Hard part: rows are identified by grid position, but scrollback is
unbounded and *reflows* on resize — no stable object ID. Candidate
approaches:
- Append-only log of rows pushed out of the grid (ignore reflow, client
  rewraps) — tractable, probably v2 answer
- Versioned scrollback "pages" — closer to true sync, more complex

Needs ghostty-vt API for reading scrollback contents either way.
