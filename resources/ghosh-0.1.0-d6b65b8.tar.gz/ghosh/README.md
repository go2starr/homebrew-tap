# ghosh

ghostty + mosh: a mosh-style remote shell over QUIC. Server runs the
authoritative terminal (libghostty-vt) and syncs idempotent per-row state
updates over QUIC datagrams; full-state snapshots ride uni streams on
attach/reattach. Sessions survive client death and network changes.

## Build prerequisite: libghostty-vt

Needs a static libghostty-vt built from a ghostty checkout with **zig 0.15.2
exactly** (newer zig breaks ghostty's build):

```sh
git clone --depth 1 https://github.com/ghostty-org/ghostty /tmp/ghostty
cd /tmp/ghostty
zig build -Demit-lib-vt=true -Demit-xcframework=false -Doptimize=ReleaseFast
```

`ghosh-vt/build.rs` looks for `lib/libghostty-vt.a` and `include/` under
`$GHOSTTY_VT_DIR`. If that variable is not set, it looks for a prebuilt bundle
at `vendor/ghostty-vt`.

To build the prebuilt bundle used by the Homebrew tap:

```sh
cd /Users/starr/dev/dream/projects/ghosh
brew install zig@0.15
./scripts/package-ghostty-vt.sh
```

To use that bundle directly from the repo without setting `GHOSTTY_VT_DIR`:

```sh
cd /Users/starr/dev/dream/projects/ghosh
mkdir -p vendor
tar -C vendor -xzf dist/ghostty-vt-macos-arm64-*.tar.gz
cargo build --release -p ghosh
```

## Usage

```sh
ghosh user@host        # ssh bootstrap: starts a session daemon remotely,
                       # connects over QUIC. Requires ghosh-server on the
                       # remote PATH (override with GHOSH_SERVER_CMD).
```

Ctrl-Q detaches. Rerunning `ghosh user@host` reattaches to the existing
session (cached in `~/.ghosh/sessions/`) with full screen state — kill the
client as hard as you like. The session daemon exits when the shell exits.

Each session gets its own daemon, ephemeral UDP port, fresh self-signed cert,
and a random 16-byte token; the client pins exactly that cert and presents
the token in Hello. Trust rides entirely on the ssh channel, mosh-style.

Local dev mode (no ssh, no token):

```sh
cargo run --bin ghosh-server   # terminal 1: writes cert+addr to ~/.ghosh
cargo run --bin ghosh          # terminal 2: attaches
cargo run --bin ghosh -- host:4500   # or direct with ~/.ghosh/cert.der
```

## Crates

- `ghosh-vt` — safe wrapper over libghostty-vt: dirty-row tracking,
  full-state VT snapshots, per-row idempotent VT repaints.
- `ghosh` — wire protocol (postcard), per-client object sync engine, and the
  `ghosh` / `ghosh-server` binaries.

## Not yet

Incremental mode/title sync (snapshot-only today), scrollback, predictive
echo, multi-client attach, auto-reconnect on connection loss.
