#!/usr/bin/env bash
set -euo pipefail

root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
work="${GHOSH_GHOSTTY_WORKDIR:-/tmp/ghosh-ghostty-vt}"
ghostty_ref="${GHOSTTY_REF:-main}"
zig_bin="${ZIG:-}"

if [[ -z "$zig_bin" ]]; then
  if [[ -x /opt/homebrew/opt/zig@0.15/bin/zig ]]; then
    zig_bin=/opt/homebrew/opt/zig@0.15/bin/zig
  else
    zig_bin=zig
  fi
fi

mkdir -p "$work"

if [[ ! -d "$work/ghostty/.git" ]]; then
  git clone https://github.com/ghostty-org/ghostty.git "$work/ghostty"
fi

git -C "$work/ghostty" fetch --tags origin
git -C "$work/ghostty" checkout "$ghostty_ref"

zig_version="$("$zig_bin" version)"
if [[ "$zig_version" != 0.15.2 ]]; then
  echo "expected zig 0.15.2, got $zig_version from $zig_bin" >&2
  echo "install with: brew install zig@0.15" >&2
  exit 1
fi

(
  cd "$work/ghostty"
  "$zig_bin" build -Demit-lib-vt=true -Demit-xcframework=false -Doptimize=ReleaseFast
)

arch="$(uname -m)"
case "$arch" in
  arm64) artifact_arch="macos-arm64" ;;
  x86_64) artifact_arch="macos-x86_64" ;;
  *) artifact_arch="macos-$arch" ;;
esac

version="$(git -C "$work/ghostty" rev-parse --short HEAD)"
bundle="$work/ghostty-vt"
artifact="$root/dist/ghostty-vt-$artifact_arch-$version.tar.gz"

rm -rf "$bundle"
mkdir -p "$bundle/lib" "$bundle/include"
cp "$work/ghostty/zig-out/lib/libghostty-vt.a" "$bundle/lib/"
cp -R "$work/ghostty/zig-out/include/." "$bundle/include/"
printf '%s\n' "$version" > "$bundle/GHOSTTY_REVISION"

mkdir -p "$root/dist"
tar -C "$work" -czf "$artifact" ghostty-vt
shasum -a 256 "$artifact"
echo "$artifact"
