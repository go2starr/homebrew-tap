//! Safe wrapper over libghostty-vt for ghosh.
//!
//! One `Terminal` owns a libghostty terminal plus a render state used for
//! dirty-row tracking. Not thread-safe; confine to a single task.

mod ffi {
    #![allow(
        non_upper_case_globals,
        non_camel_case_types,
        non_snake_case,
        dead_code,
        unsafe_op_in_unsafe_fn
    )]
    include!(concat!(env!("OUT_DIR"), "/bindings.rs"));
}

use std::mem;
use std::ptr;

use ffi::*;

#[derive(Debug, thiserror::Error)]
#[error("libghostty-vt error: {what} returned {code}")]
pub struct VtError {
    what: &'static str,
    code: i32,
}

fn check(result: GhosttyResult, what: &'static str) -> Result<(), VtError> {
    if result == GhosttyResult_GHOSTTY_SUCCESS {
        Ok(())
    } else {
        Err(VtError { what, code: result })
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Cursor {
    pub x: u16,
    pub y: u16,
    pub visible: bool,
}

pub struct Terminal {
    term: GhosttyTerminal,
    render: GhosttyRenderState,
    iter: GhosttyRenderStateRowIterator,
    cols: u16,
    rows: u16,
}

// Raw pointers from libghostty; safe to move between threads as long as all
// access goes through &mut self / &self from one task at a time.
unsafe impl Send for Terminal {}

impl Terminal {
    /// New terminal with no scrollback (replica-side: the host tty owns
    /// scrollback). For server-side use, see [`Terminal::with_scrollback`].
    pub fn new(cols: u16, rows: u16) -> Result<Self, VtError> {
        Self::with_scrollback(cols, rows, 0)
    }

    /// New terminal retaining up to `max_scrollback` history rows.
    pub fn with_scrollback(cols: u16, rows: u16, max_scrollback: usize) -> Result<Self, VtError> {
        unsafe {
            let mut term: GhosttyTerminal = ptr::null_mut();
            let opts = GhosttyTerminalOptions {
                cols,
                rows,
                max_scrollback,
            };
            check(
                ghostty_terminal_new(ptr::null(), &mut term, opts),
                "terminal_new",
            )?;

            let mut render: GhosttyRenderState = ptr::null_mut();
            check(
                ghostty_render_state_new(ptr::null(), &mut render),
                "render_state_new",
            )?;

            let mut iter: GhosttyRenderStateRowIterator = ptr::null_mut();
            check(
                ghostty_render_state_row_iterator_new(ptr::null(), &mut iter),
                "row_iterator_new",
            )?;

            Ok(Self {
                term,
                render,
                iter,
                cols,
                rows,
            })
        }
    }

    pub fn cols(&self) -> u16 {
        self.cols
    }

    pub fn rows(&self) -> u16 {
        self.rows
    }

    /// Feed PTY output bytes through the VT parser.
    pub fn write(&mut self, bytes: &[u8]) {
        unsafe { ghostty_terminal_vt_write(self.term, bytes.as_ptr(), bytes.len()) }
    }

    pub fn resize(&mut self, cols: u16, rows: u16) -> Result<(), VtError> {
        unsafe {
            check(
                ghostty_terminal_resize(self.term, cols, rows, 8, 16),
                "terminal_resize",
            )?;
        }
        self.cols = cols;
        self.rows = rows;
        Ok(())
    }

    pub fn cursor(&self) -> Result<Cursor, VtError> {
        unsafe {
            let mut x: u16 = 0;
            let mut y: u16 = 0;
            let mut visible = true;
            check(
                ghostty_terminal_get(
                    self.term,
                    GhosttyTerminalData_GHOSTTY_TERMINAL_DATA_CURSOR_X,
                    &mut x as *mut _ as *mut _,
                ),
                "get cursor_x",
            )?;
            check(
                ghostty_terminal_get(
                    self.term,
                    GhosttyTerminalData_GHOSTTY_TERMINAL_DATA_CURSOR_Y,
                    &mut y as *mut _ as *mut _,
                ),
                "get cursor_y",
            )?;
            check(
                ghostty_terminal_get(
                    self.term,
                    GhosttyTerminalData_GHOSTTY_TERMINAL_DATA_CURSOR_VISIBLE,
                    &mut visible as *mut _ as *mut _,
                ),
                "get cursor_visible",
            )?;
            Ok(Cursor { x, y, visible })
        }
    }

    /// Query one terminal mode (DEC private when `ansi` is false).
    pub fn mode(&self, value: u16, ansi: bool) -> Result<bool, VtError> {
        // ghostty_mode_new is a C static inline; pack the bits ourselves:
        // bits 0-14 = value, bit 15 = ANSI flag.
        let mode: GhosttyMode = (value & 0x7fff) | ((ansi as u16) << 15);
        unsafe {
            let mut out = false;
            check(
                ghostty_terminal_mode_get(self.term, mode, &mut out),
                "mode_get",
            )?;
            Ok(out)
        }
    }

    /// Terminal title as set by OSC 0/2; empty if never set.
    pub fn title(&self) -> Result<String, VtError> {
        unsafe {
            let mut s: GhosttyString = mem::zeroed();
            check(
                ghostty_terminal_get(
                    self.term,
                    GhosttyTerminalData_GHOSTTY_TERMINAL_DATA_TITLE,
                    &mut s as *mut _ as *mut _,
                ),
                "get title",
            )?;
            if s.len == 0 {
                return Ok(String::new());
            }
            let bytes = std::slice::from_raw_parts(s.ptr, s.len);
            Ok(String::from_utf8_lossy(bytes).into_owned())
        }
    }

    /// Update dirty tracking and return the rows that changed since the last
    /// call, resetting all dirty state. A full-dirty frame returns every row.
    pub fn take_dirty_rows(&mut self) -> Result<Vec<u16>, VtError> {
        unsafe {
            check(
                ghostty_render_state_update(self.render, self.term),
                "render_state_update",
            )?;

            let mut global: GhosttyRenderStateDirty =
                GhosttyRenderStateDirty_GHOSTTY_RENDER_STATE_DIRTY_FALSE;
            check(
                ghostty_render_state_get(
                    self.render,
                    GhosttyRenderStateData_GHOSTTY_RENDER_STATE_DATA_DIRTY,
                    &mut global as *mut _ as *mut _,
                ),
                "get global dirty",
            )?;
            let full = global == GhosttyRenderStateDirty_GHOSTTY_RENDER_STATE_DIRTY_FULL;

            check(
                ghostty_render_state_get(
                    self.render,
                    GhosttyRenderStateData_GHOSTTY_RENDER_STATE_DATA_ROW_ITERATOR,
                    &mut self.iter as *mut _ as *mut _,
                ),
                "get row iterator",
            )?;

            let mut dirty = Vec::new();
            let mut idx: u16 = 0;
            while ghostty_render_state_row_iterator_next(self.iter) {
                let mut row_dirty = false;
                check(
                    ghostty_render_state_row_get(
                        self.iter,
                        GhosttyRenderStateRowData_GHOSTTY_RENDER_STATE_ROW_DATA_DIRTY,
                        &mut row_dirty as *mut _ as *mut _,
                    ),
                    "row dirty",
                )?;
                if full || row_dirty {
                    dirty.push(idx);
                }
                if row_dirty {
                    let clean = false;
                    check(
                        ghostty_render_state_row_set(
                            self.iter,
                            GhosttyRenderStateRowOption_GHOSTTY_RENDER_STATE_ROW_OPTION_DIRTY,
                            &clean as *const _ as *const _,
                        ),
                        "row clean",
                    )?;
                }
                idx += 1;
            }

            let clean = GhosttyRenderStateDirty_GHOSTTY_RENDER_STATE_DIRTY_FALSE;
            check(
                ghostty_render_state_set(
                    self.render,
                    GhosttyRenderStateOption_GHOSTTY_RENDER_STATE_OPTION_DIRTY,
                    &clean as *const _ as *const _,
                ),
                "set global clean",
            )?;

            Ok(dirty)
        }
    }

    /// Serialize the full terminal state as VT bytes (the resync message).
    pub fn snapshot_vt(&self) -> Result<Vec<u8>, VtError> {
        unsafe {
            let mut opts: GhosttyFormatterTerminalOptions = mem::zeroed();
            opts.size = mem::size_of::<GhosttyFormatterTerminalOptions>();
            opts.emit = GhosttyFormatterFormat_GHOSTTY_FORMATTER_FORMAT_VT;
            opts.extra.size = mem::size_of::<GhosttyFormatterTerminalExtra>();
            opts.extra.modes = true;
            opts.extra.scrolling_region = true;
            opts.extra.screen.size = mem::size_of::<GhosttyFormatterScreenExtra>();
            opts.extra.screen.cursor = true;
            opts.extra.screen.style = true;
            opts.extra.screen.charsets = true;
            self.format(opts, "snapshot")
        }
    }

    /// Serialize one row as a self-contained, idempotent VT repaint:
    /// absolute cursor position + erase line + styled row content + reset.
    /// The caller is responsible for restoring the cursor afterwards.
    pub fn row_vt(&self, y: u16) -> Result<Vec<u8>, VtError> {
        unsafe {
            let start = self.grid_ref(0, y)?;
            let end = self.grid_ref(self.cols - 1, y)?;
            let mut sel: GhosttySelection = mem::zeroed();
            sel.size = mem::size_of::<GhosttySelection>();
            sel.start = start;
            sel.end = end;
            sel.rectangle = false;

            let mut opts: GhosttyFormatterTerminalOptions = mem::zeroed();
            opts.size = mem::size_of::<GhosttyFormatterTerminalOptions>();
            opts.emit = GhosttyFormatterFormat_GHOSTTY_FORMATTER_FORMAT_VT;
            opts.trim = true;
            opts.extra.size = mem::size_of::<GhosttyFormatterTerminalExtra>();
            opts.extra.screen.size = mem::size_of::<GhosttyFormatterScreenExtra>();
            opts.selection = &sel;

            let content = self.format(opts, "row format")?;
            // Selection output may end with a line break; row payloads must
            // never move beyond their own row.
            let content = match content.iter().position(|&b| b == b'\r' || b == b'\n') {
                Some(i) => &content[..i],
                None => &content[..],
            };

            let mut out = format!("\x1b[{};1H\x1b[0m\x1b[2K", y + 1).into_bytes();
            out.extend_from_slice(content);
            out.extend_from_slice(b"\x1b[0m");
            Ok(out)
        }
    }

    /// How many rows of scrollback history the terminal currently holds.
    pub fn scrollback_rows(&self) -> Result<usize, VtError> {
        unsafe {
            let mut n: usize = 0;
            check(
                ghostty_terminal_get(
                    self.term,
                    GhosttyTerminalData_GHOSTTY_TERMINAL_DATA_SCROLLBACK_ROWS,
                    &mut n as *mut _ as *mut _,
                ),
                "get scrollback_rows",
            )?;
            Ok(n)
        }
    }

    /// VT-encode the scrollback history (lines that have scrolled out of
    /// the live grid). Empty when no scrollback exists. Plain VT — no
    /// modes/cursor/style extras, just the line content with styling.
    /// Intended use: write straight to the host tty so the host's natural
    /// scrollback buffer absorbs it before the live grid is repainted.
    pub fn scrollback_vt(&self) -> Result<Vec<u8>, VtError> {
        let n = self.scrollback_rows()?;
        self.scrollback_vt_tail(n)
    }

    /// VT-encode the last `tail_rows` rows of scrollback history. Used by
    /// the server to send only the lines that scrolled past since the
    /// client's last attach. Clamped to the available history; 0 returns
    /// empty.
    pub fn scrollback_vt_tail(&self, tail_rows: usize) -> Result<Vec<u8>, VtError> {
        let total = self.scrollback_rows()?;
        let take = tail_rows.min(total);
        if take == 0 {
            return Ok(Vec::new());
        }
        unsafe {
            let start = self.history_ref(0, (total - take) as u32)?;
            let end = self.history_ref(self.cols - 1, (total - 1) as u32)?;
            let mut sel: GhosttySelection = mem::zeroed();
            sel.size = mem::size_of::<GhosttySelection>();
            sel.start = start;
            sel.end = end;
            sel.rectangle = false;

            let mut opts: GhosttyFormatterTerminalOptions = mem::zeroed();
            opts.size = mem::size_of::<GhosttyFormatterTerminalOptions>();
            opts.emit = GhosttyFormatterFormat_GHOSTTY_FORMATTER_FORMAT_VT;
            opts.trim = true;
            opts.extra.size = mem::size_of::<GhosttyFormatterTerminalExtra>();
            opts.extra.screen.size = mem::size_of::<GhosttyFormatterScreenExtra>();
            opts.selection = &sel;
            self.format(opts, "scrollback format")
        }
    }

    /// Plain-text contents of one row (debugging / tests).
    pub fn row_text(&self, y: u16) -> Result<String, VtError> {
        unsafe {
            let start = self.grid_ref(0, y)?;
            let end = self.grid_ref(self.cols - 1, y)?;
            let mut sel: GhosttySelection = mem::zeroed();
            sel.size = mem::size_of::<GhosttySelection>();
            sel.start = start;
            sel.end = end;

            let mut opts: GhosttyFormatterTerminalOptions = mem::zeroed();
            opts.size = mem::size_of::<GhosttyFormatterTerminalOptions>();
            opts.emit = GhosttyFormatterFormat_GHOSTTY_FORMATTER_FORMAT_PLAIN;
            opts.trim = true;
            opts.extra.size = mem::size_of::<GhosttyFormatterTerminalExtra>();
            opts.extra.screen.size = mem::size_of::<GhosttyFormatterScreenExtra>();
            opts.selection = &sel;

            let bytes = self.format(opts, "row text")?;
            Ok(String::from_utf8_lossy(&bytes).trim_end().to_string())
        }
    }

    unsafe fn grid_ref(&self, x: u16, y: u16) -> Result<GhosttyGridRef, VtError> {
        let point = GhosttyPoint {
            tag: GhosttyPointTag_GHOSTTY_POINT_TAG_ACTIVE,
            value: GhosttyPointValue {
                coordinate: GhosttyPointCoordinate { x, y: y as u32 },
            },
        };
        let mut out: GhosttyGridRef = mem::zeroed();
        check(
            ghostty_terminal_grid_ref(self.term, point, &mut out),
            "grid_ref",
        )?;
        Ok(out)
    }

    unsafe fn history_ref(&self, x: u16, y: u32) -> Result<GhosttyGridRef, VtError> {
        let point = GhosttyPoint {
            tag: GhosttyPointTag_GHOSTTY_POINT_TAG_HISTORY,
            value: GhosttyPointValue {
                coordinate: GhosttyPointCoordinate { x, y },
            },
        };
        let mut out: GhosttyGridRef = mem::zeroed();
        check(
            ghostty_terminal_grid_ref(self.term, point, &mut out),
            "history_ref",
        )?;
        Ok(out)
    }

    unsafe fn format(
        &self,
        opts: GhosttyFormatterTerminalOptions,
        what: &'static str,
    ) -> Result<Vec<u8>, VtError> {
        let mut formatter: GhosttyFormatter = ptr::null_mut();
        check(
            ghostty_formatter_terminal_new(ptr::null(), &mut formatter, self.term, opts),
            what,
        )?;

        let mut needed: usize = 0;
        let r = ghostty_formatter_format_buf(formatter, ptr::null_mut(), 0, &mut needed);
        if r != GhosttyResult_GHOSTTY_OUT_OF_SPACE && r != GhosttyResult_GHOSTTY_SUCCESS {
            ghostty_formatter_free(formatter);
            return Err(VtError { what, code: r });
        }

        let mut buf = vec![0u8; needed];
        let mut written: usize = 0;
        let result =
            ghostty_formatter_format_buf(formatter, buf.as_mut_ptr(), buf.len(), &mut written);
        ghostty_formatter_free(formatter);
        check(result, what)?;
        buf.truncate(written);
        Ok(buf)
    }
}

impl Drop for Terminal {
    fn drop(&mut self) {
        unsafe {
            ghostty_render_state_row_iterator_free(self.iter);
            ghostty_render_state_free(self.render);
            ghostty_terminal_free(self.term);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn dirty_tracking_cycles() {
        let mut t = Terminal::new(80, 24).unwrap();
        t.write(b"line one\r\nline two\r\n");
        let dirty = t.take_dirty_rows().unwrap();
        assert_eq!(dirty.len(), 24, "first frame is fully dirty");

        t.write(b"\x1b[s\x1b[1;1HX\x1b[u");
        let dirty = t.take_dirty_rows().unwrap();
        assert!(dirty.contains(&0), "edited row dirty: {dirty:?}");
        assert!(dirty.len() < 24, "not full dirty: {dirty:?}");

        let dirty = t.take_dirty_rows().unwrap();
        assert!(dirty.is_empty(), "no-op frame clean: {dirty:?}");
    }

    #[test]
    fn snapshot_is_fixed_point() {
        let mut t = Terminal::new(80, 24).unwrap();
        t.write(b"$ echo hi\r\nhi\r\n\x1b[1;32mok\x1b[0m\r\n$ ");
        let snap = t.snapshot_vt().unwrap();

        let mut replica = Terminal::new(80, 24).unwrap();
        replica.write(&snap);
        assert_eq!(replica.snapshot_vt().unwrap(), snap);
        assert_eq!(replica.cursor().unwrap(), t.cursor().unwrap());
    }

    #[test]
    fn row_vt_repaints_row_idempotently() {
        let mut t = Terminal::new(80, 24).unwrap();
        t.write(b"first\r\n\x1b[31msecond in red\x1b[0m\r\nthird");

        let mut replica = Terminal::new(80, 24).unwrap();
        // Pre-fill the target row with garbage to prove the repaint clears it.
        replica.write(b"\x1b[2;1Hgarbage garbage garbage");

        let row = t.row_vt(1).unwrap();
        replica.write(&row);
        assert_eq!(replica.row_text(1).unwrap(), "second in red");

        // Idempotent: applying twice changes nothing.
        replica.write(&row);
        assert_eq!(replica.row_text(1).unwrap(), "second in red");
        assert_eq!(t.row_text(1).unwrap(), "second in red");
    }

    #[test]
    fn mode_and_title_read_back() {
        let mut t = Terminal::new(80, 24).unwrap();
        assert!(!t.mode(2004, false).unwrap(), "bracketed paste starts off");
        assert!(!t.mode(1049, false).unwrap(), "alt screen starts off");

        t.write(b"\x1b[?2004h\x1b[?1049h\x1b]2;hello world\x07");
        assert!(t.mode(2004, false).unwrap());
        assert!(t.mode(1049, false).unwrap());
        assert_eq!(t.title().unwrap(), "hello world");

        t.write(b"\x1b[?2004l");
        assert!(!t.mode(2004, false).unwrap());
    }

    #[test]
    fn resize_works() {
        let mut t = Terminal::new(80, 24).unwrap();
        t.write(b"hello\r\n");
        t.take_dirty_rows().unwrap();
        t.resize(100, 30).unwrap();
        assert_eq!((t.cols(), t.rows()), (100, 30));
        let dirty = t.take_dirty_rows().unwrap();
        assert!(!dirty.is_empty());
    }

    #[test]
    fn empty_terminal_title_is_empty_string() {
        let t = Terminal::new(80, 24).unwrap();
        assert_eq!(t.title().unwrap(), "");
    }

    #[test]
    fn title_can_be_replaced() {
        let mut t = Terminal::new(80, 24).unwrap();
        t.write(b"\x1b]2;first\x07");
        assert_eq!(t.title().unwrap(), "first");
        t.write(b"\x1b]2;second\x07");
        assert_eq!(t.title().unwrap(), "second");
    }

    #[test]
    fn cursor_visible_toggles_with_dec_25() {
        let mut t = Terminal::new(80, 24).unwrap();
        assert!(t.cursor().unwrap().visible, "cursor visible by default");
        t.write(b"\x1b[?25l");
        assert!(!t.cursor().unwrap().visible);
        t.write(b"\x1b[?25h");
        assert!(t.cursor().unwrap().visible);
    }

    #[test]
    fn dirty_row_iterator_returns_each_row_once_per_frame() {
        let mut t = Terminal::new(80, 24).unwrap();
        t.write(b"line one\r\n");
        let dirty = t.take_dirty_rows().unwrap();
        let mut sorted = dirty.clone();
        sorted.sort_unstable();
        sorted.dedup();
        assert_eq!(
            dirty.len(),
            sorted.len(),
            "no duplicate row indices: {dirty:?}"
        );
    }

    #[test]
    fn scrollback_starts_empty_with_max_zero() {
        let t = Terminal::new(80, 24).unwrap();
        assert_eq!(t.scrollback_rows().unwrap(), 0);
        assert!(t.scrollback_vt().unwrap().is_empty());
    }

    #[test]
    fn scrollback_captures_lines_that_scrolled_out() {
        let mut t = Terminal::with_scrollback(80, 24, 100).unwrap();
        // Write 30 lines; the grid is 24 high so 6 lines should drop into
        // scrollback after the auto-scroll.
        for i in 0..30 {
            t.write(format!("line-{i:02}\r\n").as_bytes());
        }
        let n = t.scrollback_rows().unwrap();
        assert!(n >= 5, "expected at least 5 history rows; got {n}");

        let history = t.scrollback_vt().unwrap();
        let text = String::from_utf8_lossy(&history);
        // Lines that scrolled out (00..05) appear in history; live grid keeps the tail.
        assert!(
            text.contains("line-00"),
            "history should include early lines: {text:?}"
        );
        assert!(
            !text.contains("line-29"),
            "live tail not in history: {text:?}"
        );
    }

    #[test]
    fn scrollback_vt_tail_returns_last_n_rows() {
        let mut t = Terminal::with_scrollback(80, 24, 100).unwrap();
        for i in 0..30 {
            t.write(format!("L-{i:02}\r\n").as_bytes());
        }
        let n = t.scrollback_rows().unwrap();
        assert!(n >= 3);
        let tail = t.scrollback_vt_tail(3).unwrap();
        let text = String::from_utf8_lossy(&tail);
        // Last 3 history rows: lines just before the live grid window.
        // Live tail starts around line 7 (grid is 24 high), so history
        // contains lines 0..~5. tail(3) gives the latest history rows.
        let lines: Vec<&str> = text.lines().filter(|l| !l.is_empty()).collect();
        assert!(
            lines.len() <= 3,
            "tail returned more than 3 lines: {lines:?}"
        );
        // Earliest line shouldn't appear in tail(3).
        assert!(!text.contains("L-00"), "early line in tail: {text:?}");
    }

    #[test]
    fn scrollback_vt_tail_zero_is_empty() {
        let mut t = Terminal::with_scrollback(80, 24, 100).unwrap();
        for i in 0..30 {
            t.write(format!("L-{i}\r\n").as_bytes());
        }
        assert!(t.scrollback_vt_tail(0).unwrap().is_empty());
    }

    #[test]
    fn scrollback_disabled_drops_overflow() {
        // max=0 (the replica configuration) means scrollback never grows
        // even under heavy overflow — rows scroll into oblivion.
        let mut t = Terminal::new(80, 24).unwrap();
        for i in 0..200 {
            t.write(format!("line-{i:03}\r\n").as_bytes());
        }
        assert_eq!(
            t.scrollback_rows().unwrap(),
            0,
            "max_scrollback=0: no history"
        );
        assert!(t.scrollback_vt().unwrap().is_empty());
    }

    #[test]
    fn row_vt_for_each_row_under_resize_roundtrips() {
        // After resize, row_vt() for any row in range should still produce
        // a usable repaint that a fresh replica applies cleanly.
        let mut t = Terminal::new(80, 24).unwrap();
        t.write(b"a\r\nb\r\nc");
        t.resize(60, 30).unwrap();
        let _ = t.take_dirty_rows().unwrap();

        let mut replica = Terminal::new(60, 30).unwrap();
        for y in 0..30 {
            let payload = t.row_vt(y).unwrap();
            replica.write(&payload);
        }
        for y in 0..30 {
            assert_eq!(
                replica.row_text(y).unwrap(),
                t.row_text(y).unwrap(),
                "row {y}"
            );
        }
    }
}
