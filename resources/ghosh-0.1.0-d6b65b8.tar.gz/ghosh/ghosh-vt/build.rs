use std::env;
use std::path::PathBuf;

fn main() {
    let ghostty_out = ghostty_vt_dir();

    let out = PathBuf::from(env::var("OUT_DIR").unwrap());
    // Copy only the .a next to our build output so the linker can't pick the dylib.
    std::fs::copy(
        ghostty_out.join("lib/libghostty-vt.a"),
        out.join("libghostty-vt.a"),
    )
    .unwrap_or_else(|e| {
        panic!(
            "copy libghostty-vt.a from {}: {e}",
            ghostty_out.join("lib").display()
        )
    });
    println!("cargo:rustc-link-search=native={}", out.display());
    println!("cargo:rustc-link-lib=static=ghostty-vt");
    println!("cargo:rerun-if-env-changed=GHOSTTY_VT_DIR");
    println!("cargo:rerun-if-changed={}", ghostty_out.display());

    let bindings = bindgen::Builder::default()
        .header(
            ghostty_out
                .join("include/ghostty/vt.h")
                .display()
                .to_string(),
        )
        .clang_arg(format!("-I{}", ghostty_out.join("include").display()))
        .allowlist_function("ghostty_.*")
        .allowlist_type("Ghostty.*")
        .allowlist_var("GHOSTTY_.*")
        .generate()
        .expect("bindgen failed");

    bindings
        .write_to_file(out.join("bindings.rs"))
        .expect("write bindings");
}

fn ghostty_vt_dir() -> PathBuf {
    if let Ok(dir) = env::var("GHOSTTY_VT_DIR") {
        return PathBuf::from(dir);
    }

    let manifest_dir = PathBuf::from(env::var("CARGO_MANIFEST_DIR").unwrap());
    let vendored = manifest_dir.join("../vendor/ghostty-vt");
    if vendored.join("lib/libghostty-vt.a").exists() {
        return vendored;
    }

    panic!(
        "libghostty-vt not found. Set GHOSTTY_VT_DIR or unpack the prebuilt bundle at {}",
        vendored.display()
    );
}
