# Scrollback sync

Status: design (2026-06-12). Not yet implemented.

## Goal

After a detach/reattach (or a hard kill + reconnect), the user can scroll
up in their local terminal and see what scrolled past while they were
detached. Same experience as `mosh + tmux attach` collapsed into the
single tool.

## Non-goals (v1)

- Scrolling back *while actively attached*. The client lives in
  alt-screen during a session; scrollback in alt-screen is meaningless
  by design. If you want live scrollback, use tmux remotely.
- Reflow on resize. v1 preserves scrollback as a fixed-width snapshot
  of bytes; later resizes leave existing scrollback lines as they were
  produced. (mosh does the same.)
- Multi-client coherence. Per-client scrollback offsets etc. — moot
  while we are single-client.

## Minimal design: scrollback-on-reattach

**Insight that shrinks the problem:** during an attached session the
client is in alt-screen, so host-terminal scrollback can't be observed
anyway. Scrollback only *matters* when a user reattaches and wants to
see what they missed. So we don't need a continuous sync; we only need
the snapshot at attach time to carry enough history.

### Wire

Add one field to `Snapshot`:

```rust
pub struct Snapshot {
    // ...existing fields...
    /// VT bytes representing scrollback history (lines that have scrolled
    /// out of the live grid). Empty if the server has no scrollback or
    /// scrollback is disabled. Plain CR/LF separated VT lines —
    /// applied BEFORE the live grid snapshot so they end up in the host
    /// terminal's natural scrollback buffer.
    pub scrollback: Vec<u8>,
}
```

That's the only protocol change. PROTO_VERSION bumps 1→2.

### Server

- `Terminal::new` uses `max_scrollback = 2000` instead of 0. This is the
  one knob the server cares about; everything else falls out.
- New `Terminal::scrollback_vt(&self) -> Result<Vec<u8>>` formats the
  history-only region as VT bytes (selection from
  `GHOSTTY_POINT_TAG_HISTORY` start to end). Plain `FORMAT_VT`, no
  modes/cursor extras — we want lines, not full terminal state.
- Snapshot construction calls `term.scrollback_vt()` and stuffs the
  result into the new field.

### Client

The render flow on snapshot reception becomes:

```text
1. Exit alt-screen (so host main screen + scrollback accept the dump)
2. Write \x1b[0m
3. Write snap.scrollback bytes verbatim   <-- accumulates in host scrollback
4. Re-enter alt-screen
5. Existing snapshot replay (clear + snap.vt + title + cursor)
```

The first attach starts with empty `scrollback`, so the dump is a no-op
and behavior is identical to today. On reattach the server's history
flows through the host's natural scrollback machinery — no client-side
buffer, no custom scroll UI.

The dump is unconditional and idempotent: applying a snapshot
overwrites the alt-screen content but every dump appends to host
scrollback, so a re-reattach would duplicate it. To avoid that we send
the dump ONLY in the snapshot that follows a fresh-token bootstrap or
re-bootstrap (i.e. a session resumption), NOT on the initial attach in
a brand-new session. The server already distinguishes these (Daemon
vs. Foreground SessionDir), so it sets `scrollback` only when serving
a Daemon-mode reattach.

Actually no — even simpler: the server sends scrollback on every
snapshot, but only includes lines added since the last attach. Server
tracks `scrollback_high_seq_at_last_attach`; the snapshot's scrollback
field contains only lines pushed out since that point. First attach
sees zero (nothing scrolled before they connected), reattach sees
exactly the missed window. This auto-resets on detach.

### Implementation order

1. ghosh-vt: `scrollback_vt()` + `max_scrollback` plumbed through
   `TerminalOptions`. Unit test: write enough lines to scroll, confirm
   scrollback_vt returns those lines.
2. proto: add field, bump PROTO_VERSION. Roundtrip test.
3. Server: track scrollback delta between attach and current. Use it
   when constructing the Attach event's snapshot.
4. Client: scrollback-aware snapshot render order. Idempotent enough
   that an empty field is a literal no-op.
5. E2E: tmux-driven test — detach, generate output remotely, reattach,
   verify the missed lines are in tmux's capture-pane history (use
   `capture-pane -S -200 -p` to dump scrollback).

## Open questions

- `max_scrollback = 2000` is arbitrary. Mosh defaults to ~1000 IIRC.
  Make it configurable? (For v1: hardcoded 2000.)
- What if the user keeps a session attached for a week without
  detaching? Scrollback grows unbounded on the server until the next
  detach resets the "last attach high seq." Acceptable: it's the
  bounded-size server-side buffer (max_scrollback), pruned naturally.
- Does the scrollback dump break prediction? It happens before snapshot
  application, which clears the prediction engine — safe.
- Multi-byte / wide-glyph rows in scrollback: emitted as-is by the
  formatter (ghostty-vt handles utf-8 natively in VT output), so
  should be transparent. Test with a wide-glyph line to confirm.
