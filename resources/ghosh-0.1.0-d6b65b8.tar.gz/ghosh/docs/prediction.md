# Predictive local echo

Status: implemented (2026-06-12) — `predict.rs` (engine), `replica.rs`
(client replica), overlay in `main.rs::apply_loop`. Sections below updated
to match the implementation where it diverged from the original design;
divergences are marked **[changed in impl]**. Remaining: validation on the
real ~180ms link (adaptive ramp can't engage on loopback).

## Goal

Keystrokes appear immediately instead of after a full RTT. This is the
difference between "works over wifi" and "daily driver" — at the 180ms
test link, unpredicted typing is visibly sluggish.

Mosh is the prior art; this design borrows its core ideas (speculative
overlay, confidence ramp, underline-when-uncertain) but adapts them to
ghosh's object-sync model, which actually makes validation simpler than
SSP: row updates are idempotent full repaints, so "what the server thinks
this row looks like" is always directly comparable to a prediction.

## Non-goals (v1)

- Predicting anything beyond printable chars and backspace (no arrows,
  no newline/CR, no kill-line).
- Predicting across line wrap (no prediction in the last column).
- UTF-8 grapheme prediction (start ASCII printable; widen later).
- Prediction inside alt-screen apps (suppressed; full-screen apps echo
  asynchronously and mispredictions are common).

## Prerequisite: client replica (phase 1)

Today the client writes server payloads straight to stdout
(`apply_loop`, main.rs). Prediction requires an authoritative local copy
to roll back to, so the client gains a ghosh-vt `Terminal` replica:

- Snapshot → `replica.write(snap.vt)` (after clear).
- Row update → `replica.write(payload)` (payloads are CUP-prefixed full
  row repaints, so they apply cleanly).
- Rendering becomes: redraw dirty rows from `replica.row_vt(y)`, then
  paint the prediction overlay on top, then position the cursor.

With an empty overlay this is behaviorally identical to today's direct
write-through — phase 1 lands alone and is verified against the existing
e2e suite before any prediction code exists.

Dependency: **Modes sync** (TODO.md) must land first so the replica
knows it's in alt-screen and can suppress prediction. Until then the
engine treats "unknown" as "don't predict".

## Architecture

Three pieces, all client-side. No protocol changes: `Update.input_seq`
(the echo of the last applied input seq) is already in every datagram
and is the only signal needed.

### 1. Prediction engine

On each keystroke that we choose to predict, record:

```
Prediction {
    seq: u64,            // the Input seq that carried this keystroke
    cell: (x, y),        // where the glyph should appear
    glyph: char,         // what we predicted (None for backspace-blank)
    decided_at_gen: Option<u64>,  // see "validation" below
    made_at: Instant,    // for the glitch timer
}
```

Predicted cursor = server cursor advanced through pending predictions.

What we predict:
- Printable ASCII `0x20..=0x7e`, when cursor is not in the last column:
  glyph at cursor, cursor advances.
- Backspace: cursor retreats, cell blanked.

What pauses prediction: any input we don't model (newline, ctrl chars,
escape sequences, paste). Existing predictions stand — the server will
confirm or refute them — but no *new* predictions are made until
`input_seq` catches up to the unmodeled input's seq (we no longer know
where the cursor really is).

What suppresses prediction entirely: alt-screen active, cursor hidden,
or engine confidence is Off (below).

### 2. Validation — the subtle part

`input_seq >= pred.seq` means the server *applied* the keystroke, but
NOT that we've seen the resulting row content: the datagram carrying the
row repaint can be lost while a later datagram (higher `input_seq`, no
row payload) arrives first. Comparing the prediction against a stale
replica row would manufacture a false misprediction.

**[changed in impl]** The original rule (prediction only *checkable*
when the row's applied gen >= the deciding update's gen) wedged in
practice: per-row gens lag the update's global gen whenever unrelated
output bumps the generation between the echo and the tick, and an idle
row is never re-sent — the prediction hung forever (found live, fixed,
regression test `row_gen_lagging_update_gen_does_not_wedge`). The
implemented rule is asymmetric:

- **Confirm on match, any time.** The predicted glyph appearing on the
  authoritative row is ground truth regardless of gen bookkeeping.
- **Mispredict only when decided AND caught up:** the prediction was
  decided (`input_seq >= seq`, stamped `decided_at_gen = update.gen`)
  and the row's applied gen >= `decided_at_gen`, yet the cell differs.
- **Expiry backstop (1s):** a decided-but-never-checkable prediction
  (echo suppressed, e.g. `stty -echo`) is presumed wrong: clear all,
  go dark. Counted separately from mispredictions.

Either failure clears the ENTIRE overlay (the predicted cursor was
derived from the bad prediction, so every later prediction is garbage),
redraws affected rows from the replica, and drops confidence to Off.

Accepted narrow race (conservative direction): a row repainted by
concurrent non-echo output in the same tick that decides a prediction
can look like a misprediction — the overlay clears and confidence
resets, which is cosmetic, never wrong content.

**Pause collapse [changed in impl]:** the design's separate
"pause-until-seq" state collapsed into cursor knowledge. Unmodeled
input just sets the predicted cursor to unknown; the cursor is
re-adopted from server state only when `input_seq` has caught up to
everything typed and nothing is pending. Same semantics, one less
state variable.

**Bare updates (server change):** updates were only sent when rows were
dirty, so input that echoes nothing (`read -s`, cursor-only motion)
never delivered the `input_seq` echo and the engine could never
re-adopt the cursor. The server tick now sends an object-less Update
whenever `input_seq` or the cursor changed since the last send. Lost
bare datagrams are not retransmitted; any later real update carries the
same fields.

### 3. Display overlay & confidence ramp

States:

- **Off** — predictions are tracked and validated but not displayed.
  This is the start state and the state after any misprediction.
  Tracking-without-display means confidence can recover invisibly.
- **On** — predictions display immediately, styled normally.
- (within On) **glitch flagging** — if any outstanding prediction has
  been undecided for > 250ms, ALL displayed predictions switch to
  underline until the backlog clears. Mosh's trick: the user sees
  exactly which characters are speculative when the link degrades.

Transitions:
- Off → On: N consecutive confirmed predictions (start N=5) AND
  smoothed RTT > 40ms (`Connection::rtt()`); below that the real echo
  is fast enough that prediction only adds flicker risk.
- On → Off: any misprediction.

Rendering a frame (on apply event or predicted keystroke):
1. Write authoritative payloads into replica; collect dirty rows.
2. Emit `replica.row_vt(y)` for each dirty row.
3. Re-paint overlay cells intersecting those rows (and any new
   prediction): CUP + glyph, underlined iff glitch-flagged.
4. Position cursor: predicted cursor if any prediction is undecided
   and engine is On, else server cursor.

## Implementation phases (all landed 2026-06-12)

0. Modes/Title sync — alt-screen guard needs it. DONE (see TODO.md).
1. Client replica + render-from-replica refactor (`replica.rs`). DONE.
2. Engine in shadow mode (`predict.rs`): track + validate; stats to
   `GHOSH_PREDICT_LOG=<path>`. DONE.
3. Display: overlay paint + reconciliation in `apply_loop`, confidence
   ramp, glitch underline. DONE. `GHOSH_PREDICT=always|adaptive|never`
   (mosh-style) overrides the ramp — `always` is also how the display
   path is testable on a fast loopback.

Verified e2e (loopback, tmux-driven): shadow stats confirm cleanly;
`read -s` expiry; silent-`cat` misprediction wipes the overlay;
alt-screen (vim) suppression; SIGSTOP'd server shows speculative paint,
glitch underline appears at 250ms, resume reconciles with zero residue.

## Testing

- Unit: engine state machine — confirm/refute sequencing, the
  stale-row/decided_at_gen race, overlay clear on misprediction,
  pause-on-unmodeled-input.
- E2E (tmux harness per the established recipe, stderr to file):
  - typing into bash prompt at ~180ms (mikes-macbook-pro): predictions
    appear instantly, confirm cleanly, no visual residue after server
    echo.
  - misprediction: type into a `stty -echo` context (e.g. password
    prompt) — engine recovers, screen ends correct.
  - vim/alt-screen: prediction suppressed.
  - packet loss + reorder if feasible (macOS dummynet/`dnctl` link
    conditioning) for the decided_at_gen race.

## Open questions

- Whether to predict CR→fresh-prompt-line (mosh does, with low
  confidence). Punted; revisit after shadow-mode data.
- Word-wide backspace (option-delete) and kill-line: unmodeled for now,
  they just pause prediction.
- Should glitch threshold scale with RTT instead of fixed 250ms? Try
  max(250ms, 2×SRTT) if fixed feels wrong on the 180ms link.
