//! Predictive local echo engine (see docs/prediction.md).
//!
//! Tracks speculative keystrokes against the authoritative replica. The
//! engine itself never paints; it tells the caller what it predicts and the
//! caller decides whether to display (shadow mode displays nothing).
//!
//! Core rule: a prediction is *decided* when the server has echoed an
//! `input_seq` >= the prediction's seq, but it only becomes *checkable*
//! once the predicted cell's row has been applied at a generation >= the
//! generation that decided it — otherwise a lost row datagram would make us
//! compare against a stale row and manufacture a false misprediction.

use std::time::{Duration, Instant};

use crate::proto::{CursorState, ObjId};
use crate::replica::Replica;

/// Display predictions only on links slower than this; below it the real
/// echo is fast enough that speculation just risks flicker.
const MIN_RTT_TO_DISPLAY: Duration = Duration::from_millis(40);
/// Consecutive confirmations required before displaying.
const HITS_TO_DISPLAY: u32 = 5;
/// A decided prediction unconfirmed for this long is presumed wrong
/// (e.g. stty -echo): drop everything and go dark.
const EXPIRY: Duration = Duration::from_secs(1);
/// Any prediction outstanding longer than this flags the link as glitchy:
/// displayed predictions switch to underline until the backlog clears.
const GLITCH: Duration = Duration::from_millis(250);

/// Display policy (GHOSH_PREDICT env): mosh-style always/adaptive/never.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Mode {
    Adaptive,
    Always,
    Never,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Prediction {
    pub seq: u64,
    pub x: u16,
    pub y: u16,
    /// None = cell predicted blank (backspace).
    pub glyph: Option<char>,
    decided_at_gen: Option<u64>,
    made_at: Instant,
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct Stats {
    pub made: u64,
    pub confirmed: u64,
    pub mispredicted: u64,
    pub expired: u64,
    pub confirm_latency_total: Duration,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Display {
    /// Track and validate, paint nothing. Start state; state after any
    /// misprediction. Confidence rebuilds invisibly.
    Off,
    /// Paint predictions immediately.
    On,
}

pub struct Engine {
    pending: Vec<Prediction>,
    /// Predicted cursor. None = unknown (unmodeled input since the last
    /// catch-up); no predictions are made while unknown.
    cursor: Option<(u16, u16)>,
    /// Highest input seq the user has produced.
    last_seq: u64,
    pub mode: Mode,
    display: Display,
    hits: u32,
    expiry: Duration,
    pub stats: Stats,
}

impl Default for Engine {
    fn default() -> Self {
        Self {
            pending: Vec::new(),
            cursor: None,
            last_seq: 0,
            mode: Mode::Adaptive,
            display: Display::Off,
            hits: 0,
            expiry: EXPIRY,
            stats: Stats::default(),
        }
    }
}

impl Engine {
    pub fn new() -> Self {
        Self::default()
    }

    #[cfg(test)]
    fn with_expiry(expiry: Duration) -> Self {
        Self { expiry, ..Self::new() }
    }

    pub fn display(&self) -> Display {
        match self.mode {
            Mode::Always => Display::On,
            Mode::Never => Display::Off,
            Mode::Adaptive => self.display,
        }
    }

    /// Glitchy link: some prediction has been outstanding too long.
    /// Displayed predictions should be underlined while this holds.
    pub fn glitch(&self, now: Instant) -> bool {
        self.pending.iter().any(|p| now.duration_since(p.made_at) >= GLITCH)
    }

    pub fn pending(&self) -> &[Prediction] {
        &self.pending
    }

    /// Predicted cursor if the engine knows better than the server echo.
    pub fn cursor(&self) -> Option<(u16, u16)> {
        if self.pending.is_empty() {
            None
        } else {
            self.cursor
        }
    }

    /// Full resync (attach/reattach): all speculation is moot.
    pub fn on_snapshot(&mut self, input_seq: u64, cursor: CursorState) {
        self.pending.clear();
        self.cursor = (input_seq >= self.last_seq).then_some((cursor.x, cursor.y));
    }

    /// User input that was sent to the server as `seq`. Returns predictions
    /// made from this input (for the caller to paint when display is On).
    pub fn on_input(
        &mut self,
        seq: u64,
        bytes: &[u8],
        replica: &Replica,
        now: Instant,
    ) -> Vec<Prediction> {
        self.last_seq = self.last_seq.max(seq);
        if replica.modes().alt_screen {
            // Full-screen apps echo asynchronously; don't even track.
            self.cursor = None;
            return Vec::new();
        }

        let mut made = Vec::new();
        for &b in bytes {
            let Some((x, y)) = self.cursor else { continue };
            match b {
                0x20..=0x7e => {
                    // Never predict into the last column: wrap behavior is
                    // the app's call, so the cursor becomes unknown.
                    if x + 1 >= replica.cols() {
                        self.cursor = None;
                        continue;
                    }
                    made.push(self.push(seq, x, y, Some(b as char), now));
                    self.cursor = Some((x + 1, y));
                }
                0x7f | 0x08 => {
                    if x == 0 {
                        self.cursor = None;
                        continue;
                    }
                    made.push(self.push(seq, x - 1, y, None, now));
                    self.cursor = Some((x - 1, y));
                }
                _ => {
                    // Unmodeled (newline, escape sequences, ctrl chars):
                    // existing predictions stand, but we no longer know
                    // where the cursor is until the server catches up.
                    self.cursor = None;
                }
            }
        }
        made
    }

    /// Server state advanced: an update or snapshot arrived and has been
    /// applied to the replica. Returns true if all speculation was dropped
    /// (misprediction/expiry) and any painted overlay must be erased.
    pub fn on_server_state(
        &mut self,
        gen: u64,
        input_seq: u64,
        server_cursor: CursorState,
        replica: &Replica,
        rtt: Duration,
        now: Instant,
    ) -> bool {
        if replica.modes().alt_screen {
            self.pending.clear();
            self.cursor = None;
            return false;
        }

        for p in &mut self.pending {
            if p.decided_at_gen.is_none() && input_seq >= p.seq {
                p.decided_at_gen = Some(gen);
            }
        }

        let mut cleared = false;
        let mut i = 0;
        while i < self.pending.len() {
            let p = self.pending[i];
            // Confirm on a match no matter the bookkeeping: the predicted
            // glyph being on the authoritative row is the ground truth.
            // (Row gens lag the update's global gen, so gating confirmation
            // on applied_gen >= decided can wedge forever on an idle row.)
            let want = p.glyph.unwrap_or(' ');
            let got = replica.cell_char(p.x, p.y).unwrap_or(' ');
            if got == want {
                self.stats.confirmed += 1;
                self.stats.confirm_latency_total += now.duration_since(p.made_at);
                self.hits += 1;
                self.pending.remove(i);
                continue;
            }
            // A mismatch only counts once the input was echoed AND the row
            // has been applied at/after the deciding generation — otherwise
            // we may be looking at a stale row (lost datagram).
            if let Some(decided) = p.decided_at_gen {
                if replica.applied_gen(ObjId::Row(p.y)) >= decided {
                    self.stats.mispredicted += 1;
                    cleared = true;
                    break;
                }
            }
            if now.duration_since(p.made_at) >= self.expiry {
                self.stats.expired += 1;
                cleared = true;
                break;
            }
            i += 1;
        }

        if cleared {
            // The predicted cursor was derived from the bad prediction;
            // nothing speculative can be trusted now.
            self.pending.clear();
            self.cursor = None;
            self.hits = 0;
            self.display = Display::Off;
        }

        if self.pending.is_empty() && input_seq >= self.last_seq {
            self.cursor = Some((server_cursor.x, server_cursor.y));
        }

        if self.display == Display::Off
            && self.hits >= HITS_TO_DISPLAY
            && rtt >= MIN_RTT_TO_DISPLAY
        {
            self.display = Display::On;
        }

        cleared
    }

    fn push(&mut self, seq: u64, x: u16, y: u16, glyph: Option<char>, now: Instant) -> Prediction {
        // Latest prediction per cell wins; an older one for the same cell
        // can no longer be observed and would only fake a misprediction.
        self.pending.retain(|p| (p.x, p.y) != (x, y));
        let p = Prediction { seq, x, y, glyph, decided_at_gen: None, made_at: now };
        self.pending.push(p);
        self.stats.made += 1;
        p
    }
}

/// Tracks which cells currently show speculative paint on the host tty so
/// the renderer can restore them from the replica when speculation goes
/// away. Stateful sibling to the (stateless) `Engine`.
#[derive(Debug, Default)]
pub struct Overlay {
    painted: std::collections::HashSet<(u16, u16)>,
}

impl Overlay {
    pub fn new() -> Self {
        Self::default()
    }

    /// Clear bookkeeping (snapshot, resize): no cells on screen any more.
    pub fn forget(&mut self) {
        self.painted.clear();
    }

    /// Paint a fresh prediction into `out` and remember it.
    pub fn paint(&mut self, out: &mut Vec<u8>, p: &Prediction, glitch: bool) {
        write_paint(out, p, glitch);
        self.painted.insert((p.x, p.y));
    }

    /// Re-paint every pending prediction (e.g. after a glitch transition).
    pub fn repaint_all(&mut self, out: &mut Vec<u8>, engine: &Engine, glitch: bool) {
        for p in engine.pending() {
            self.paint(out, p, glitch);
        }
    }

    /// After an update, reconcile the on-screen overlay with whatever the
    /// engine still considers pending:
    ///
    /// 1. Rows that previously showed speculation but the engine no longer
    ///    predicts AND this update didn't repaint: redraw from replica.
    /// 2. Surviving predictions whose row was just repainted (by this
    ///    update, OR by the restore in step 1): paint back on top.
    pub fn reconcile(
        &mut self,
        out: &mut Vec<u8>,
        replica: &Replica,
        engine: &Engine,
        touched_rows: &[u16],
        glitch: bool,
    ) {
        let displaying = engine.display() == Display::On;
        let desired: std::collections::HashSet<(u16, u16)> = if displaying {
            engine.pending().iter().map(|p| (p.x, p.y)).collect()
        } else {
            std::collections::HashSet::new()
        };
        let touched: std::collections::HashSet<u16> = touched_rows.iter().copied().collect();

        let mut restore: Vec<u16> = self
            .painted
            .iter()
            .filter(|c| !desired.contains(c) && !touched.contains(&c.1))
            .map(|c| c.1)
            .collect();
        restore.sort_unstable();
        restore.dedup();
        for &y in &restore {
            if y < replica.rows() {
                if let Ok(bytes) = replica.row_vt(y) {
                    out.extend_from_slice(&bytes);
                }
            }
        }

        if displaying {
            for p in engine.pending() {
                if touched.contains(&p.y)
                    || restore.contains(&p.y)
                    || !self.painted.contains(&(p.x, p.y))
                {
                    write_paint(out, p, glitch);
                }
            }
        }
        self.painted = desired;
    }

    #[cfg(test)]
    pub(crate) fn painted_cells(&self) -> &std::collections::HashSet<(u16, u16)> {
        &self.painted
    }
}

/// One speculative cell. Predictions render in default style (the
/// authoritative repaint restores real colors); underlined when glitchy.
fn write_paint(out: &mut Vec<u8>, p: &Prediction, glitch: bool) {
    let sgr = if glitch { "\x1b[0;4m" } else { "\x1b[0m" };
    out.extend_from_slice(
        format!("\x1b[{};{}H{}{}\x1b[0m", p.y + 1, p.x + 1, sgr, p.glyph.unwrap_or(' '))
            .as_bytes(),
    );
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::proto::{Modes, ObjUpdate, Snapshot, Update};

    const RTT: Duration = Duration::from_millis(100);

    /// Server terminal + client replica + engine, wired like the real app.
    struct Rig {
        server: ghosh_vt::Terminal,
        replica: Replica,
        engine: Engine,
        gen: u64,
        input_seq: u64,
        now: Instant,
    }

    impl Rig {
        fn new() -> Self {
            let mut rig = Self {
                server: ghosh_vt::Terminal::new(80, 24).unwrap(),
                replica: Replica::new(80, 24).unwrap(),
                engine: Engine::new(),
                gen: 1,
                input_seq: 0,
                now: Instant::now(),
            };
            rig.snapshot();
            rig
        }

        fn server_cursor(&self) -> CursorState {
            let c = self.server.cursor().unwrap();
            CursorState { x: c.x, y: c.y, visible: c.visible }
        }

        fn snapshot(&mut self) {
            let snap = Snapshot {
                gen: self.gen,
                input_seq: self.input_seq,
                cols: 80,
                rows: 24,
                cursor: self.server_cursor(),
                vt: self.server.snapshot_vt().unwrap(),
                title: String::new(),
                modes: Modes::default(),
                scrollback: Vec::new(),
            };
            self.replica.apply_snapshot(&snap).unwrap();
            self.engine.on_snapshot(snap.input_seq, snap.cursor);
        }

        fn type_bytes(&mut self, bytes: &[u8]) -> Vec<Prediction> {
            self.input_seq += 1;
            self.engine.on_input(self.input_seq, bytes, &self.replica, self.now)
        }

        /// Server echoes `vt` and sends one update carrying the dirty rows
        /// plus the current input_seq.
        fn echo(&mut self, vt: &[u8]) -> bool {
            self.server.write(vt);
            self.gen += 1;
            let objs = self
                .server
                .take_dirty_rows()
                .unwrap()
                .into_iter()
                .map(|r| ObjUpdate {
                    id: ObjId::Row(r),
                    gen: self.gen,
                    payload: self.server.row_vt(r).unwrap(),
                })
                .collect();
            self.update(objs)
        }

        /// An update with no row payloads (input echo only).
        fn bare_update(&mut self) -> bool {
            self.gen += 1;
            self.update(Vec::new())
        }

        fn update(&mut self, objs: Vec<ObjUpdate>) -> bool {
            let update = Update {
                gen: self.gen,
                input_seq: self.input_seq,
                cursor: self.server_cursor(),
                objs,
            };
            self.replica.apply_update(&update).unwrap();
            self.engine.on_server_state(
                update.gen,
                update.input_seq,
                update.cursor,
                &self.replica,
                RTT,
                self.now,
            )
        }
    }

    #[test]
    fn printable_predicts_and_confirms() {
        let mut rig = Rig::new();
        let made = rig.type_bytes(b"hi");
        assert_eq!(made.len(), 2);
        assert_eq!((made[0].x, made[0].glyph), (0, Some('h')));
        assert_eq!((made[1].x, made[1].glyph), (1, Some('i')));
        assert_eq!(rig.engine.cursor(), Some((2, 0)));

        let cleared = rig.echo(b"hi");
        assert!(!cleared);
        assert_eq!(rig.engine.stats.confirmed, 2);
        assert!(rig.engine.pending().is_empty());
        assert_eq!(rig.engine.cursor(), None, "no speculation outstanding");
    }

    #[test]
    fn misprediction_clears_everything() {
        let mut rig = Rig::new();
        rig.type_bytes(b"abc");
        // Server echoes something else (e.g. the app uppercases).
        let cleared = rig.echo(b"ABC");
        assert!(cleared);
        assert_eq!(rig.engine.stats.mispredicted, 1, "first mismatch stops checking");
        assert!(rig.engine.pending().is_empty());
        assert_eq!(rig.engine.display(), Display::Off);
    }

    #[test]
    fn decided_but_stale_row_defers_judgment() {
        let mut rig = Rig::new();
        rig.type_bytes(b"x");
        // input_seq echo arrives first, row datagram lost/late: decided,
        // but the row was last applied before the deciding gen.
        let cleared = rig.bare_update();
        assert!(!cleared, "stale row must not fake a misprediction");
        assert_eq!(rig.engine.pending().len(), 1, "still pending");
        assert_eq!(rig.engine.stats.mispredicted, 0);

        // The row repaint lands: now checkable, and it matches.
        let cleared = rig.echo(b"x");
        assert!(!cleared);
        assert_eq!(rig.engine.stats.confirmed, 1);
    }

    #[test]
    fn unmodeled_input_blocks_prediction_until_caught_up() {
        let mut rig = Rig::new();
        rig.type_bytes(b"\r");
        assert!(rig.type_bytes(b"a").is_empty(), "cursor unknown after CR");

        // Server processes everything typed so far; cursor becomes known.
        rig.echo(b"\r\n$ a");
        assert!(!rig.type_bytes(b"b").is_empty(), "predicting again after catch-up");
    }

    #[test]
    fn backspace_predicts_blank_and_replaces_same_cell() {
        let mut rig = Rig::new();
        rig.type_bytes(b"a");
        rig.type_bytes(b"\x7f");
        let pending = rig.engine.pending();
        assert_eq!(pending.len(), 1, "blank replaced the glyph at the same cell");
        assert_eq!((pending[0].x, pending[0].glyph), (0, None));
        assert_eq!(rig.engine.cursor(), Some((0, 0)));

        // Shell echoes "a" then erases it.
        let cleared = rig.echo(b"a\x08 \x08");
        assert!(!cleared);
        assert_eq!(rig.engine.stats.confirmed, 1);
    }

    #[test]
    fn expiry_drops_speculation_without_misprediction_blame() {
        let mut rig = Rig::new();
        rig.engine = Engine::with_expiry(Duration::from_millis(50));
        rig.snapshot();

        rig.type_bytes(b"secret"); // stty -echo: server will never paint it
        rig.bare_update();
        assert!(!rig.engine.pending().is_empty());

        rig.now += Duration::from_millis(100);
        let cleared = rig.bare_update();
        assert!(cleared);
        assert_eq!(rig.engine.stats.expired, 1);
        assert_eq!(rig.engine.stats.mispredicted, 0);
        assert!(rig.engine.pending().is_empty());
    }

    #[test]
    fn alt_screen_suppresses_prediction() {
        let mut rig = Rig::new();
        // Flip the replica into alt screen via a Modes update.
        rig.gen += 1;
        let modes = Modes { alt_screen: true, ..Modes::default() };
        let update = Update {
            gen: rig.gen,
            input_seq: rig.input_seq,
            cursor: rig.server_cursor(),
            objs: vec![ObjUpdate {
                id: ObjId::Modes,
                gen: rig.gen,
                payload: postcard::to_allocvec(&modes).unwrap(),
            }],
        };
        rig.replica.apply_update(&update).unwrap();

        assert!(rig.type_bytes(b"j").is_empty(), "no prediction in alt screen");
        assert_eq!(rig.engine.stats.made, 0);
    }

    #[test]
    fn last_column_is_never_predicted() {
        let mut rig = Rig::new();
        rig.echo(b"\x1b[1;79H"); // cursor to col 78 (0-indexed)
        assert_eq!(rig.type_bytes(b"a").len(), 1, "col 78 ok");
        assert!(rig.type_bytes(b"b").is_empty(), "col 79 (last) not predicted");
        assert_eq!(rig.engine.cursor(), None, "cursor unknown once wrap is possible");
    }

    #[test]
    fn confidence_ramp_enables_display_and_misprediction_kills_it() {
        let mut rig = Rig::new();
        for i in 0..5 {
            rig.type_bytes(&[b'a' + i]);
            rig.echo(&[b'a' + i]);
        }
        assert_eq!(rig.engine.stats.confirmed, 5);
        assert_eq!(rig.engine.display(), Display::On);

        rig.type_bytes(b"q");
        rig.echo(b"Z");
        assert_eq!(rig.engine.display(), Display::Off);
    }

    #[test]
    fn fast_links_stay_dark() {
        let mut rig = Rig::new();
        for i in 0..6 {
            rig.type_bytes(&[b'a' + i]);
            rig.server.write(&[b'a' + i]);
            rig.gen += 1;
            let objs: Vec<ObjUpdate> = rig
                .server
                .take_dirty_rows()
                .unwrap()
                .into_iter()
                .map(|r| ObjUpdate {
                    id: ObjId::Row(r),
                    gen: rig.gen,
                    payload: rig.server.row_vt(r).unwrap(),
                })
                .collect();
            let update = Update {
                gen: rig.gen,
                input_seq: rig.input_seq,
                cursor: rig.server_cursor(),
                objs,
            };
            rig.replica.apply_update(&update).unwrap();
            rig.engine.on_server_state(
                update.gen,
                update.input_seq,
                update.cursor,
                &rig.replica,
                Duration::from_millis(5), // LAN
                rig.now,
            );
        }
        assert!(rig.engine.stats.confirmed >= 5);
        assert_eq!(rig.engine.display(), Display::Off, "fast link: no display");
    }

    #[test]
    fn mode_overrides_adaptive_display() {
        let mut rig = Rig::new();
        rig.engine.mode = Mode::Always;
        assert_eq!(rig.engine.display(), Display::On, "always: on with zero confirms");

        rig.engine.mode = Mode::Never;
        for i in 0..6 {
            rig.type_bytes(&[b'a' + i]);
            rig.echo(&[b'a' + i]);
        }
        assert_eq!(rig.engine.display(), Display::Off, "never: off despite confirms");
    }

    #[test]
    fn glitch_flags_slow_outstanding_predictions() {
        let mut rig = Rig::new();
        rig.type_bytes(b"a");
        assert!(!rig.engine.glitch(rig.now), "fresh prediction: no glitch");
        assert!(rig.engine.glitch(rig.now + Duration::from_millis(300)));

        rig.echo(b"a");
        assert!(
            !rig.engine.glitch(rig.now + Duration::from_millis(300)),
            "confirmed: nothing outstanding"
        );
    }

    #[test]
    fn shell_burst_with_trailing_cr_confirms() {
        let mut rig = Rig::new();
        rig.echo(b"$ "); // prompt
        rig.type_bytes(b"echo hi\r");
        assert_eq!(rig.engine.pending().len(), 7);

        // Shell echoes the command, runs it, prints a fresh prompt.
        let cleared = rig.echo(b"echo hi\r\nhi\r\n$ ");
        assert!(!cleared);
        assert_eq!(rig.engine.stats.confirmed, 7, "pending: {:?}", rig.engine.pending());
        assert!(rig.engine.pending().is_empty());
    }

    #[test]
    fn echo_landing_before_seq_ack_confirms() {
        let mut rig = Rig::new();
        rig.type_bytes(b"x"); // seq 1
        // Echo row arrives while the server's input_seq echo lags behind.
        let typed = rig.input_seq;
        rig.input_seq = 0;
        let cleared = rig.echo(b"x");
        rig.input_seq = typed;
        assert!(!cleared);
        assert_eq!(rig.engine.stats.confirmed, 1, "match confirms without waiting for seq ack");
    }

    #[test]
    fn row_gen_lagging_update_gen_does_not_wedge() {
        // Live-bug regression: the echo row is dirtied at gen G, but by the
        // time the tick sends it, unrelated output bumped the global gen to
        // G+1. decided_at_gen = G+1 > applied row gen G; the old rule could
        // never re-check an idle row and the prediction hung forever.
        let mut rig = Rig::new();
        rig.type_bytes(b"x");

        rig.server.write(b"x");
        rig.gen += 1;
        let objs: Vec<ObjUpdate> = rig
            .server
            .take_dirty_rows()
            .unwrap()
            .into_iter()
            .map(|r| ObjUpdate {
                id: ObjId::Row(r),
                gen: rig.gen,
                payload: rig.server.row_vt(r).unwrap(),
            })
            .collect();
        rig.gen += 1; // concurrent dirt elsewhere
        let cleared = rig.update(objs);
        assert!(!cleared);
        assert_eq!(rig.engine.stats.confirmed, 1);
        assert!(rig.engine.pending().is_empty());
    }

    #[test]
    fn snapshot_resets_speculation() {
        let mut rig = Rig::new();
        rig.type_bytes(b"abc");
        assert!(!rig.engine.pending().is_empty());
        rig.snapshot();
        assert!(rig.engine.pending().is_empty());
    }

    #[test]
    fn snapshot_with_stale_input_seq_freezes_cursor() {
        // Reattach mid-keystroke: input_seq the server knew is below what
        // we've sent (the in-flight Inputs haven't reached the new
        // attach yet). Cursor must stay unknown until catch-up.
        let mut rig = Rig::new();
        rig.input_seq = 5;
        rig.engine.last_seq = 5;
        let snap = Snapshot {
            gen: rig.gen + 1,
            input_seq: 2, // server hasn't caught up
            cols: 80,
            rows: 24,
            cursor: CursorState { x: 0, y: 0, visible: true },
            vt: rig.server.snapshot_vt().unwrap(),
            title: String::new(),
            modes: Modes::default(),
            scrollback: Vec::new(),
        };
        rig.replica.apply_snapshot(&snap).unwrap();
        rig.engine.on_snapshot(snap.input_seq, snap.cursor);
        assert!(rig.type_bytes(b"a").is_empty(), "cursor unknown after stale-seq snapshot");
    }

    #[test]
    fn backspace_at_col_0_blanks_cursor_but_does_not_panic() {
        let mut rig = Rig::new();
        let made = rig.type_bytes(b"\x7f");
        assert!(made.is_empty(), "backspace at col 0 is unmodeled");
        assert_eq!(rig.engine.cursor(), None);
    }

    #[test]
    fn non_ascii_input_does_not_panic_or_predict() {
        // UTF-8 multibyte (non-ASCII); engine treats high bytes as unmodeled.
        let mut rig = Rig::new();
        let made = rig.type_bytes("é".as_bytes());
        assert!(made.is_empty());
        assert_eq!(rig.engine.cursor(), None, "cursor unknown after unmodeled bytes");
    }

    #[test]
    fn empty_input_chunk_is_a_noop() {
        let mut rig = Rig::new();
        let made = rig.type_bytes(b"");
        assert!(made.is_empty());
        assert_eq!(rig.engine.cursor(), None, "no input_seq advance, cursor stays unknown");
    }

    #[test]
    fn alt_screen_toggle_with_pending_clears_pending() {
        // Pending speculation when alt_screen flips on: engine drops it
        // (the new app has no obligation to echo what we predicted).
        let mut rig = Rig::new();
        rig.type_bytes(b"a");
        assert!(!rig.engine.pending().is_empty());

        rig.gen += 1;
        let payload = postcard::to_allocvec(&Modes { alt_screen: true, ..Modes::default() }).unwrap();
        let update = Update {
            gen: rig.gen,
            input_seq: rig.input_seq,
            cursor: rig.server_cursor(),
            objs: vec![ObjUpdate { id: ObjId::Modes, gen: rig.gen, payload }],
        };
        rig.replica.apply_update(&update).unwrap();
        rig.engine.on_server_state(
            update.gen, update.input_seq, update.cursor, &rig.replica, RTT, rig.now,
        );
        assert!(rig.engine.pending().is_empty(), "alt_screen on => clears speculation");
        assert_eq!(rig.engine.cursor(), None);
    }

    #[test]
    fn rapid_backspace_burst_keeps_one_pending_per_cell() {
        let mut rig = Rig::new();
        rig.type_bytes(b"abc"); // predicts a@0, b@1, c@2; cursor at 3
        // Three backspaces blank cells 2, 1, 0 in turn.
        rig.type_bytes(b"\x7f\x7f\x7f");
        let pending = rig.engine.pending();
        // Each cell now has exactly one prediction; latest wins.
        let glyphs: std::collections::HashMap<(u16, u16), Option<char>> = pending
            .iter()
            .map(|p| ((p.x, p.y), p.glyph))
            .collect();
        assert_eq!(glyphs.get(&(0, 0)), Some(&None));
        assert_eq!(glyphs.get(&(1, 0)), Some(&None));
        assert_eq!(glyphs.get(&(2, 0)), Some(&None));
        assert_eq!(rig.engine.cursor(), Some((0, 0)));
    }

    #[test]
    fn stats_track_made_and_confirmed_independently() {
        let mut rig = Rig::new();
        rig.type_bytes(b"ab");
        assert_eq!(rig.engine.stats.made, 2);
        assert_eq!(rig.engine.stats.confirmed, 0);
        rig.echo(b"ab");
        assert_eq!(rig.engine.stats.made, 2, "made does not move when confirming");
        assert_eq!(rig.engine.stats.confirmed, 2);
    }

    // ----- Overlay -----------------------------------------------------------

    fn paint_cmd(x: u16, y: u16, glyph: char, glitch: bool) -> Vec<u8> {
        let sgr = if glitch { "\x1b[0;4m" } else { "\x1b[0m" };
        format!("\x1b[{};{}H{}{}\x1b[0m", y + 1, x + 1, sgr, glyph).into_bytes()
    }

    #[test]
    fn overlay_paint_emits_cup_and_glyph() {
        let mut o = Overlay::new();
        let p = Prediction {
            seq: 1, x: 3, y: 5, glyph: Some('z'),
            decided_at_gen: None, made_at: Instant::now(),
        };
        let mut out = Vec::new();
        o.paint(&mut out, &p, false);
        assert_eq!(out, paint_cmd(3, 5, 'z', false));
        assert!(o.painted_cells().contains(&(3, 5)));
    }

    #[test]
    fn overlay_paint_with_glitch_underlines() {
        let mut o = Overlay::new();
        let p = Prediction {
            seq: 1, x: 0, y: 0, glyph: Some('q'),
            decided_at_gen: None, made_at: Instant::now(),
        };
        let mut out = Vec::new();
        o.paint(&mut out, &p, true);
        assert!(String::from_utf8_lossy(&out).contains("\x1b[0;4m"));
    }

    #[test]
    fn overlay_reconcile_restores_rows_when_engine_clears() {
        // Display=On with a prediction => paint => then engine clears
        // (misprediction). Reconcile must restore the painted row from
        // the replica.
        let mut rig = Rig::new();
        rig.engine.mode = Mode::Always;
        let preds = rig.type_bytes(b"a");
        let mut overlay = Overlay::new();
        let mut out = Vec::new();
        for p in &preds {
            overlay.paint(&mut out, p, false);
        }
        assert!(!out.is_empty());
        assert!(overlay.painted_cells().contains(&(0, 0)));

        // Kill the pending so engine no longer wants overlay on row 0,
        // and reconcile with no touched rows (matches a bare update).
        rig.engine.pending.clear();
        let mut out = Vec::new();
        overlay.reconcile(&mut out, &rig.replica, &rig.engine, &[], false);
        assert!(!out.is_empty(), "row 0 must have been restored from replica");
        assert!(overlay.painted_cells().is_empty(), "tracked set updated to match engine");
    }

    #[test]
    fn overlay_reconcile_repaints_survivor_when_row_touched() {
        // Pending prediction at (0,0); update repaints row 0 (the row
        // we predicted into). Overlay must re-emit the prediction so it
        // stays on screen on top of the authoritative row.
        let mut rig = Rig::new();
        rig.engine.mode = Mode::Always;
        let preds = rig.type_bytes(b"a");
        let mut overlay = Overlay::new();
        let mut out = Vec::new();
        for p in &preds {
            overlay.paint(&mut out, p, false);
        }

        let mut out = Vec::new();
        overlay.reconcile(&mut out, &rig.replica, &rig.engine, &[0], false);
        assert!(
            String::from_utf8_lossy(&out).contains("\x1b[1;1H"),
            "should re-paint at row 0/col 0: {out:?}",
        );
    }

    #[test]
    fn overlay_reconcile_off_drops_paint_but_preserves_engine_state() {
        let mut rig = Rig::new();
        // Adaptive display starts Off, but the engine is still tracking.
        let preds = rig.type_bytes(b"a");
        let mut overlay = Overlay::new();
        let mut out = Vec::new();
        // Simulate display flipping On then Off again between paint and
        // reconcile: paint first as if On, then reconcile while Off.
        for p in &preds {
            overlay.paint(&mut out, p, false);
        }
        assert!(!overlay.painted_cells().is_empty());

        let mut out = Vec::new();
        overlay.reconcile(&mut out, &rig.replica, &rig.engine, &[], false);
        assert!(!out.is_empty(), "row must be restored from replica");
        assert!(overlay.painted_cells().is_empty());
        assert!(!rig.engine.pending().is_empty(), "engine still tracks for confirmation");
    }

    #[test]
    fn overlay_forget_clears_tracked_cells_without_emitting() {
        let mut o = Overlay::new();
        let p = Prediction {
            seq: 1, x: 0, y: 0, glyph: Some('q'),
            decided_at_gen: None, made_at: Instant::now(),
        };
        let mut out = Vec::new();
        o.paint(&mut out, &p, false);
        assert!(!o.painted_cells().is_empty());
        o.forget();
        assert!(o.painted_cells().is_empty());
    }
}
