//! ghosh client: raw-mode tty, forwards input, applies synced state.
//! Ctrl-Q detaches (the session keeps running server-side).

use std::io::Write;
use std::sync::Arc;
use std::time::Instant;

use anyhow::{Context, Result};
use crossterm::terminal;
use ghosh::predict::{self, Engine, Overlay};
use ghosh::proto::{self, Ack, ClientMsg, CursorState, ServerMsg, UniFrame, Update};
use ghosh::replica::Replica;
use quinn::{ClientConfig, Connection, Endpoint};
use rustls::pki_types::CertificateDer;
use rustls::RootCertStore;
use tokio::sync::mpsc;

const DETACH_KEY: u8 = 0x11; // ctrl-q
/// Test hook: when GHOSH_ROAM=1 this triggers `Endpoint::rebind` to a fresh
/// ephemeral UDP socket, exercising QUIC connection migration. Suppressed
/// in normal builds so a stray ctrl-r in a shell doesn't break the session.
const ROAM_KEY: u8 = 0x12; // ctrl-r
const ATTACH_TIMEOUT: std::time::Duration = std::time::Duration::from_secs(5);
/// Reconnect when the QUIC connection drops mid-session: shorter than the
/// initial attach so a wedged server doesn't keep us hanging.
const RECONNECT_TIMEOUT: std::time::Duration = std::time::Duration::from_secs(3);

struct RawGuard;

impl RawGuard {
    fn new() -> Result<Self> {
        terminal::enable_raw_mode()?;
        print!("\x1b[?1049h"); // alternate screen
        std::io::stdout().flush()?;
        Ok(Self)
    }
}

impl Drop for RawGuard {
    fn drop(&mut self) {
        let _ = terminal::disable_raw_mode();
        print!("\x1b[?1049l\x1b[0m\x1b[?25h");
        let _ = std::io::stdout().flush();
    }
}

use ghosh::proto::Snapshot;

enum Apply {
    Snapshot(Snapshot),
    Update(Update),
    Resize { cols: u16, rows: u16 },
    Input { seq: u64, bytes: Vec<u8> },
}

/// Resolve "host:port" to an IPv4 socket address (our endpoint binds v4).
fn resolve(addr: &str) -> Result<std::net::SocketAddr> {
    use std::net::ToSocketAddrs;
    addr.to_socket_addrs()?
        .find(|a| a.is_ipv4())
        .context("no IPv4 address found")
}

/// Resolve a target to a fresh session and attach to it.
///
/// Always creates a new session — no cross-invocation cache. The
/// in-process reconnect path uses the returned `SessionInfo` (so a single
/// dropped QUIC connection survives transparently), but a brand-new
/// `ghosh user@host` invocation always bootstraps fresh.
///
/// - no target: local demo server via ~/.ghosh/{addr,cert.der}
/// - "host:port": direct connect, cert from ~/.ghosh/cert.der
/// - "user@host" / "host": ssh bootstrap
async fn connect_session(
    target: Option<String>,
    cols: u16,
    rows: u16,
) -> Result<(Endpoint, SessionInfo, Connection, quinn::SendStream, quinn::RecvStream)> {
    let dir = ghosh::demo_dir();
    let sess = match target {
        None => {
            let addr = std::fs::read_to_string(dir.join("addr"))
                .context("no target given and ~/.ghosh/addr not found — usage: ghosh [user@host | host:port]")?;
            local_session(&dir, addr.trim())?
        }
        Some(t) if t.contains(':') => local_session(&dir, &t)?,
        Some(t) => bootstrap_ssh(&t).await?,
    };
    let (endpoint, conn, send, recv) = attach(&sess, cols, rows, ATTACH_TIMEOUT).await?;
    Ok((endpoint, sess, conn, send, recv))
}

fn local_session(dir: &std::path::Path, addr: &str) -> Result<SessionInfo> {
    let (host, port) = addr.rsplit_once(':').context("expected host:port")?;
    Ok(SessionInfo {
        host: host.to_string(),
        port: port.parse()?,
        token: Vec::new(),
        cert: std::fs::read(dir.join("cert.der"))
            .context("read ~/.ghosh/cert.der — copy it from the server host")?,
    })
}

/// Run `ghosh-server --bootstrap` on the remote host over ssh and parse the
/// GHOSH-CONNECT line it prints.
///
/// Resolution order for `ssh` and `server_cmd`: env var → `~/.ghosh/config`
/// host section → config defaults section → built-in default. Env vars win
/// so a one-off invocation (`GHOSH_SERVER_CMD=... ghosh ...`) still works
/// without editing the config file.
async fn bootstrap_ssh(target: &str) -> Result<SessionInfo> {
    let cfg = ghosh::config::Config::load(&ghosh::demo_dir().join("config"));
    let ssh = std::env::var("GHOSH_SSH")
        .ok()
        .or_else(|| cfg.get(target, "ssh").map(String::from))
        .unwrap_or_else(|| "ssh".to_string());
    let server_cmd = std::env::var("GHOSH_SERVER_CMD")
        .ok()
        .or_else(|| cfg.get(target, "server_cmd").map(String::from))
        .unwrap_or_else(|| "ghosh-server".to_string());
    let mut parts = ssh.split_whitespace();
    let program = parts.next().context("empty GHOSH_SSH")?;

    eprintln!("ghosh: bootstrapping session on {target} via {program}...");
    // stdin/stderr stay on the tty so ssh can prompt for auth.
    let output = tokio::process::Command::new(program)
        .args(parts)
        .arg(target)
        .arg(format!("{server_cmd} --bootstrap"))
        .stdout(std::process::Stdio::piped())
        .output()
        .await
        .with_context(|| format!("run {program}"))?;
    anyhow::ensure!(output.status.success(), "ssh bootstrap failed ({})", output.status);

    let stdout = String::from_utf8_lossy(&output.stdout);
    let line = stdout
        .lines()
        .find(|l| l.starts_with("GHOSH-CONNECT "))
        .context("no GHOSH-CONNECT line from server — is ghosh-server on the remote PATH?")?;
    let fields: Vec<&str> = line.split_whitespace().collect();
    anyhow::ensure!(
        fields.get(1) == Some(&proto::PROTO_VERSION.to_string().as_str()),
        "server proto version mismatch: {line}"
    );

    let host = target.rsplit_once('@').map_or(target, |(_, h)| h);
    SessionInfo::from_fields(host, &fields[2..])
}

/// QUIC connect + Hello/HelloAck, with a timeout so dead cached sessions
/// fail over quickly.
async fn attach(
    sess: &SessionInfo,
    cols: u16,
    rows: u16,
    timeout: std::time::Duration,
) -> Result<(Endpoint, Connection, quinn::SendStream, quinn::RecvStream)> {
    let addr = resolve(&format!("{}:{}", sess.host, sess.port))
        .with_context(|| format!("resolve {}", sess.host))?;

    let mut roots = RootCertStore::empty();
    roots.add(CertificateDer::from(sess.cert.clone()))?;
    let mut crypto = rustls::ClientConfig::builder()
        .with_root_certificates(roots)
        .with_no_client_auth();
    crypto.alpn_protocols = vec![ghosh::ALPN.to_vec()];
    let mut config = ClientConfig::new(Arc::new(quinn::crypto::rustls::QuicClientConfig::try_from(
        crypto,
    )?));
    // quinn's default 30s idle timeout would kill quiet sessions; PING from
    // our side well inside that window.
    let mut transport = quinn::TransportConfig::default();
    transport.keep_alive_interval(Some(std::time::Duration::from_secs(10)));
    config.transport_config(Arc::new(transport));

    let mut endpoint = Endpoint::client("0.0.0.0:0".parse()?)?;
    endpoint.set_default_client_config(config);

    let attach = async {
        let conn = endpoint.connect(addr, "localhost")?.await.context("connect")?;
        let (mut control_send, mut control_recv) = conn.open_bi().await?;
        proto::write_frame(
            &mut control_send,
            &ClientMsg::Hello {
                proto: proto::PROTO_VERSION,
                token: sess.token.clone(),
                cols,
                rows,
            },
        )
        .await?;
        let ServerMsg::HelloAck { .. } = proto::read_frame(&mut control_recv).await? else {
            anyhow::bail!("expected HelloAck");
        };
        Ok((endpoint.clone(), conn, control_send, control_recv))
    };
    tokio::time::timeout(timeout, attach)
        .await
        .context("attach timed out")?
}

/// Everything needed to (re)attach to one session.
#[derive(Clone)]
struct SessionInfo {
    host: String,
    port: u16,
    token: Vec<u8>,
    cert: Vec<u8>,
}

impl SessionInfo {
    fn from_fields(host: &str, fields: &[&str]) -> Result<Self> {
        let [port, token, cert] = fields else {
            anyhow::bail!("malformed session info: {fields:?}");
        };
        Ok(Self {
            host: host.to_string(),
            port: port.parse()?,
            token: hex::decode(token)?,
            cert: hex::decode(cert)?,
        })
    }
}

/// What ended the per-session task graph. `Done` is terminal (the user or
/// the remote shell quit); `Lost` is a transport failure that the outer
/// loop will try to recover from with a fresh attach.
enum SessionEnd {
    Done(String),
    Lost(String),
}

#[tokio::main]
async fn main() -> Result<()> {
    let (cols, rows) = terminal::size()?;
    let (endpoint, sess_info, conn, control_send, control_recv) =
        connect_session(std::env::args().nth(1), cols, rows).await?;

    let _raw = RawGuard::new()?;

    // Seq counter and roam policy survive across reconnects so the server's
    // monotonic input_seq never goes backwards and Ctrl-R behavior stays
    // consistent across the session.
    let seq = Arc::new(std::sync::atomic::AtomicU64::new(0));
    let roam_enabled = std::env::var("GHOSH_ROAM").as_deref() == Ok("1");

    let mut current = Some((conn, control_send, control_recv));
    let final_reason = loop {
        let (conn, control_send, control_recv) = current.take().expect("loop populates current");
        let end = run_session_once(
            endpoint.clone(), conn, control_send, control_recv,
            cols, rows, seq.clone(), roam_enabled,
        ).await;
        match end {
            SessionEnd::Done(r) => break r,
            SessionEnd::Lost(r) => {
                eprintln!("ghosh: {r}; reconnecting...");
                match attach(&sess_info, cols, rows, RECONNECT_TIMEOUT).await {
                    Ok((_, c, cs, cr)) => current = Some((c, cs, cr)),
                    Err(e) => break format!("reconnect failed: {e:#}"),
                }
            }
        }
    };

    drop(_raw);
    println!("ghosh: {final_reason}");
    Ok(())
}

/// Spawn the per-session task graph and wait for it to finish. Returns
/// either Done (terminal) or Lost (transient, caller should reattach).
#[allow(clippy::too_many_arguments)]
async fn run_session_once(
    endpoint: Endpoint,
    conn: Connection,
    mut control_send: quinn::SendStream,
    mut control_recv: quinn::RecvStream,
    cols: u16,
    rows: u16,
    seq: Arc<std::sync::atomic::AtomicU64>,
    roam_enabled: bool,
) -> SessionEnd {
    let (done_tx, mut done_rx) = mpsc::channel::<SessionEnd>(4);
    let (apply_tx, apply_rx) = mpsc::channel::<Apply>(256);
    let (out_tx, out_rx) = mpsc::channel::<ClientMsg>(256);

    // Control writer: owns the send stream.
    let done = done_tx.clone();
    tokio::spawn(async move {
        let mut out_rx = out_rx;
        while let Some(msg) = out_rx.recv().await {
            if proto::write_frame(&mut control_send, &msg).await.is_err() {
                break;
            }
        }
        let _ = done.send(SessionEnd::Lost("control stream closed".into())).await;
    });

    // Control reader: server messages (Exit) and connection teardown.
    let done = done_tx.clone();
    let close_conn = conn.clone();
    tokio::spawn(async move {
        loop {
            match proto::read_frame::<ServerMsg>(&mut control_recv).await {
                Ok(ServerMsg::Exit { status }) => {
                    let _ = done
                        .send(SessionEnd::Done(format!("remote shell exited ({status})")))
                        .await;
                    return;
                }
                Ok(_) => {}
                Err(_) => {
                    // The Exit frame can lose the race against the server's
                    // conn close; the close reason carries the same news.
                    // ApplicationClosed with code 0 = server initiated a
                    // clean shutdown (terminal); any other close reason or
                    // a transport-level failure is recoverable.
                    let end = match close_conn.close_reason() {
                        Some(quinn::ConnectionError::ApplicationClosed(c))
                            if c.error_code == quinn::VarInt::from_u32(0) =>
                        {
                            SessionEnd::Done(format!(
                                "remote {}", String::from_utf8_lossy(&c.reason)
                            ))
                        }
                        _ => SessionEnd::Lost("connection lost".into()),
                    };
                    let _ = done.send(end).await;
                    return;
                }
            }
        }
    });

    // Uni streams: snapshots and oversized updates.
    let snap_conn = conn.clone();
    let tx = apply_tx.clone();
    tokio::spawn(async move {
        while let Ok(mut uni) = snap_conn.accept_uni().await {
            let tx = tx.clone();
            tokio::spawn(async move {
                match proto::read_frame::<UniFrame>(&mut uni).await {
                    Ok(UniFrame::Snapshot(snap)) => {
                        let _ = tx.send(Apply::Snapshot(snap)).await;
                    }
                    Ok(UniFrame::Update(update)) => {
                        let _ = tx.send(Apply::Update(update)).await;
                    }
                    Err(_) => {}
                }
            });
        }
    });

    // Update datagrams.
    let dgram_conn = conn.clone();
    let tx = apply_tx.clone();
    tokio::spawn(async move {
        while let Ok(datagram) = dgram_conn.read_datagram().await {
            if let Ok(update) = postcard::from_bytes::<Update>(&datagram) {
                if tx.send(Apply::Update(update)).await.is_err() {
                    break;
                }
            }
        }
    });

    // Apply task: owns stdout and the replica, sends acks.
    tokio::spawn(apply_loop(apply_rx, conn.clone(), cols, rows));

    // Stdin → Input frames (and the prediction engine).
    let out = out_tx.clone();
    let done = done_tx.clone();
    let tx = apply_tx.clone();
    let roam_endpoint = endpoint.clone();
    let stdin_seq = seq.clone();
    tokio::spawn(async move {
        use std::sync::atomic::Ordering;
        use tokio::io::AsyncReadExt;
        let mut stdin = tokio::io::stdin();
        let mut buf = [0u8; 1024];
        loop {
            match stdin.read(&mut buf).await {
                Ok(0) | Err(_) => break,
                Ok(n) => {
                    let bytes = &buf[..n];
                    if bytes.contains(&DETACH_KEY) {
                        let _ = done
                            .send(SessionEnd::Done(
                                "detached (session still running)".into(),
                            ))
                            .await;
                        return;
                    }
                    if roam_enabled && bytes.contains(&ROAM_KEY) {
                        let old = roam_endpoint.local_addr().ok();
                        match std::net::UdpSocket::bind("0.0.0.0:0")
                            .and_then(|s| roam_endpoint.rebind(s))
                        {
                            Ok(()) => eprintln!(
                                "ghosh: roamed from {old:?} to {:?}",
                                roam_endpoint.local_addr().ok()
                            ),
                            Err(e) => eprintln!("ghosh: rebind failed: {e}"),
                        }
                        // Filter the ctrl-r out so the shell doesn't see it.
                        let filtered: Vec<u8> = bytes.iter().copied()
                            .filter(|&b| b != ROAM_KEY).collect();
                        if filtered.is_empty() { continue; }
                        let next = stdin_seq.fetch_add(1, Ordering::Relaxed) + 1;
                        if out.send(ClientMsg::Input { seq: next, bytes: filtered.clone() }).await.is_err() {
                            break;
                        }
                        let _ = tx.send(Apply::Input { seq: next, bytes: filtered }).await;
                        continue;
                    }
                    let next = stdin_seq.fetch_add(1, Ordering::Relaxed) + 1;
                    if out.send(ClientMsg::Input { seq: next, bytes: bytes.to_vec() }).await.is_err() {
                        break;
                    }
                    let _ = tx.send(Apply::Input { seq: next, bytes: bytes.to_vec() }).await;
                }
            }
        }
    });

    // Window resize: tell the server and the local replica.
    let out = out_tx.clone();
    let tx = apply_tx.clone();
    tokio::spawn(async move {
        let mut winch =
            tokio::signal::unix::signal(tokio::signal::unix::SignalKind::window_change())
                .expect("install SIGWINCH handler");
        while winch.recv().await.is_some() {
            if let Ok((cols, rows)) = terminal::size() {
                let _ = tx.send(Apply::Resize { cols, rows }).await;
                if out.send(ClientMsg::Resize { cols, rows }).await.is_err() {
                    break;
                }
            }
        }
    });

    let end = done_rx
        .recv()
        .await
        .unwrap_or_else(|| SessionEnd::Done("done".into()));
    // Close the connection now so the server sees the teardown — if we're
    // about to reconnect this is just freeing the old path; if we're done
    // it's the normal client-exit path.
    conn.close(0u32.into(), b"client exit");
    end
}

async fn apply_loop(
    mut apply_rx: mpsc::Receiver<Apply>,
    conn: Connection,
    cols: u16,
    rows: u16,
) {
    let Ok(mut replica) = Replica::new(cols, rows) else { return };
    let mut engine = Engine::new();
    engine.mode = match std::env::var("GHOSH_PREDICT").as_deref() {
        Ok("always") => predict::Mode::Always,
        Ok("never") => predict::Mode::Never,
        _ => predict::Mode::Adaptive,
    };
    let mut log = std::env::var("GHOSH_PREDICT_LOG")
        .ok()
        .and_then(|p| std::fs::File::create(p).ok());
    let mut logged_stats = predict::Stats::default();

    let mut stdout = std::io::stdout();
    let mut server_cursor = CursorState { x: 0, y: 0, visible: true };
    let mut overlay = Overlay::new();
    let mut glitched = false;
    let mut tick = tokio::time::interval(std::time::Duration::from_millis(100));
    tick.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);

    loop {
        let mut out: Vec<u8> = Vec::new();
        let mut acks: Vec<(proto::ObjId, u64)> = Vec::new();
        // Reposition the cursor only when something happened; a keystroke
        // with display off must produce zero tty output.
        let mut place_cursor = false;

        tokio::select! {
            apply = apply_rx.recv() => {
                let Some(apply) = apply else { return };
                let now = Instant::now();
                match apply {
                    Apply::Snapshot(snap) => {
                        let Ok(o) = replica.apply_snapshot(&snap) else { return };
                        out = o;
                        server_cursor = snap.cursor;
                        engine.on_snapshot(snap.input_seq, snap.cursor);
                        overlay.forget();
                        place_cursor = true;
                    }
                    Apply::Update(update) => {
                        let Ok(outcome) = replica.apply_update(&update) else { return };
                        out = outcome.out;
                        acks = outcome.acks;
                        server_cursor = update.cursor;
                        engine.on_server_state(
                            update.gen, update.input_seq, update.cursor,
                            &replica, conn.rtt(), now,
                        );
                        overlay.reconcile(
                            &mut out, &replica, &engine,
                            &outcome.touched_rows, glitched,
                        );
                        place_cursor = true;
                        if let Some(f) = log.as_mut() {
                            log_stats(f, &engine, &mut logged_stats, &conn);
                        }
                    }
                    Apply::Input { seq, bytes } => {
                        let preds = engine.on_input(seq, &bytes, &replica, now);
                        if engine.display() == predict::Display::On {
                            for p in &preds {
                                overlay.paint(&mut out, p, glitched);
                            }
                            place_cursor = !out.is_empty();
                        }
                    }
                    Apply::Resize { cols, rows } => {
                        if replica.resize(cols, rows).is_err() {
                            return;
                        }
                        overlay.forget();
                    }
                }
            }
            _ = tick.tick() => {
                let now = Instant::now();
                let g = engine.display() == predict::Display::On && engine.glitch(now);
                if g != glitched {
                    glitched = g;
                    overlay.repaint_all(&mut out, &engine, glitched);
                    place_cursor = !out.is_empty();
                }
            }
        }

        if place_cursor {
            let cursor = match engine.cursor() {
                Some((x, y)) if engine.display() == predict::Display::On => {
                    CursorState { x, y, visible: server_cursor.visible }
                }
                _ => server_cursor,
            };
            position_cursor(&mut out, cursor);
        }
        if !out.is_empty() && stdout.write_all(&out).and_then(|()| stdout.flush()).is_err() {
            return;
        }
        if !acks.is_empty() {
            if let Ok(bytes) = postcard::to_allocvec(&Ack { acks }) {
                let _ = conn.send_datagram(bytes.into());
            }
        }
    }
}

fn log_stats(
    f: &mut std::fs::File,
    engine: &Engine,
    logged: &mut predict::Stats,
    conn: &Connection,
) {
    if engine.stats == *logged {
        return;
    }
    *logged = engine.stats;
    let s = engine.stats;
    let avg_ms = if s.confirmed > 0 {
        s.confirm_latency_total.as_millis() / s.confirmed as u128
    } else {
        0
    };
    let _ = writeln!(
        f,
        "predict: made={} confirmed={} mispred={} expired={} avg_confirm_ms={} display={:?} rtt_ms={} pending={} cursor={:?}",
        s.made, s.confirmed, s.mispredicted, s.expired, avg_ms,
        engine.display(), conn.rtt().as_millis(),
        engine.pending().len(), engine.cursor(),
    );
}

fn position_cursor(out: &mut Vec<u8>, cursor: CursorState) {
    out.extend_from_slice(format!("\x1b[{};{}H", cursor.y + 1, cursor.x + 1).as_bytes());
    out.extend_from_slice(if cursor.visible { b"\x1b[?25h" } else { b"\x1b[?25l" });
}
