//! Client-side replica: an authoritative local copy of the server terminal.
//!
//! Server payloads are applied to a ghosh-vt `Terminal`, and host-tty output
//! is rendered FROM the replica (`row_vt`) rather than passed through. That
//! gives prediction something to roll back to: the replica is always pure
//! server state, never speculation.

use std::collections::HashMap;

use anyhow::Result;

use crate::proto::{Modes, ObjId, Snapshot, Update};

/// Result of applying a server update.
#[derive(Debug, Default)]
pub struct UpdateOutcome {
    /// Bytes to write to the host tty.
    pub out: Vec<u8>,
    /// Acks to send back to the server. Contains an entry for every object
    /// in the update, even stale ones — the server only needs to know those
    /// generations no longer require re-sending.
    pub acks: Vec<(ObjId, u64)>,
    /// Rows that were repainted in `out`. Overlay reconciliation needs them
    /// to decide which speculative cells the authoritative row erased.
    pub touched_rows: Vec<u16>,
}

pub struct Replica {
    term: ghosh_vt::Terminal,
    /// Per-object generation applied to the replica; objects absent from the
    /// map are covered by `snapshot_gen`.
    applied: HashMap<ObjId, u64>,
    snapshot_gen: u64,
    modes: Modes,
}

impl Replica {
    pub fn new(cols: u16, rows: u16) -> Result<Self> {
        Ok(Self {
            term: ghosh_vt::Terminal::new(cols, rows)?,
            applied: HashMap::new(),
            snapshot_gen: 0,
            modes: Modes::default(),
        })
    }

    pub fn cols(&self) -> u16 {
        self.term.cols()
    }

    pub fn rows(&self) -> u16 {
        self.term.rows()
    }

    pub fn modes(&self) -> Modes {
        self.modes
    }

    /// Generation at which an object was last applied.
    pub fn applied_gen(&self, id: ObjId) -> u64 {
        self.applied.get(&id).copied().unwrap_or(self.snapshot_gen)
    }

    /// Plain-text character at a cell; ' ' for blanks / beyond line end.
    /// ASCII-oriented: rows containing wide glyphs may misalign (the
    /// prediction engine treats that as a misprediction, which is safe).
    pub fn cell_char(&self, x: u16, y: u16) -> Result<char> {
        let text = self.term.row_text(y)?;
        Ok(text.chars().nth(x as usize).unwrap_or(' '))
    }

    /// Authoritative repaint bytes for one row (used to erase speculation).
    pub fn row_vt(&self, y: u16) -> Result<Vec<u8>> {
        Ok(self.term.row_vt(y)?)
    }

    /// Local window changed size. The server is told separately and will
    /// resend every row at the new size; transient reflow artifacts in the
    /// replica self-heal.
    pub fn resize(&mut self, cols: u16, rows: u16) -> Result<()> {
        self.term.resize(cols, rows)?;
        Ok(())
    }

    /// Full resync. Returns host-tty bytes (scrollback + clear + state + title).
    pub fn apply_snapshot(&mut self, snap: &Snapshot) -> Result<Vec<u8>> {
        // Fresh terminal: snapshot replay into a clean state is a validated
        // fixed point; resize-then-write would reflow stale content first.
        self.term = ghosh_vt::Terminal::new(snap.cols, snap.rows)?;
        self.term.write(&snap.vt);
        let _ = self.term.take_dirty_rows()?;
        self.applied.clear();
        self.snapshot_gen = snap.gen;
        self.modes = snap.modes;

        let mut out: Vec<u8> = Vec::new();
        // Reattach: lines that scrolled past while we were detached. We
        // briefly leave alt-screen so they land in the host's natural
        // scrollback buffer, then come back to repaint the live grid.
        if !snap.scrollback.is_empty() {
            out.extend_from_slice(b"\x1b[?1049l\x1b[0m");
            out.extend_from_slice(&snap.scrollback);
            // Trailing newline guarantees the scrollback dump ends on its
            // own line, so it doesn't visually fuse with whatever was on
            // the main screen before.
            if !snap.scrollback.ends_with(b"\n") {
                out.push(b'\n');
            }
            out.extend_from_slice(b"\x1b[?1049h");
        }
        out.extend_from_slice(b"\x1b[0m\x1b[2J\x1b[H");
        out.extend_from_slice(&snap.vt);
        emit_title(&mut out, &snap.title);
        Ok(out)
    }

    /// Apply one update.
    pub fn apply_update(&mut self, update: &Update) -> Result<UpdateOutcome> {
        let mut outcome = UpdateOutcome::default();

        for obj in &update.objs {
            outcome.acks.push((obj.id, obj.gen));
            if obj.gen <= self.applied_gen(obj.id) {
                continue;
            }
            match obj.id {
                ObjId::Row(row) => {
                    // Resize race: the server may still be sending rows for
                    // the old, larger size.
                    if row >= self.term.rows() {
                        continue;
                    }
                    self.term.write(&obj.payload);
                }
                ObjId::Modes => {
                    let Ok(new) = postcard::from_bytes::<Modes>(&obj.payload) else {
                        continue;
                    };
                    emit_mode_diff(&mut outcome.out, &self.modes, &new);
                    self.modes = new;
                }
                ObjId::Title => {
                    emit_title(&mut outcome.out, &String::from_utf8_lossy(&obj.payload));
                }
            }
            self.applied.insert(obj.id, obj.gen);
        }

        // Render changed rows from the replica, not the wire payloads: the
        // replica is the single source of truth for what's on screen.
        outcome.touched_rows = self.term.take_dirty_rows()?;
        for &row in &outcome.touched_rows {
            outcome.out.extend_from_slice(&self.term.row_vt(row)?);
        }
        Ok(outcome)
    }
}

/// Always emit, even for an empty title: an empty OSC 2 clears the host
/// title, which is the correct response to a remote that unset its own.
fn emit_title(out: &mut Vec<u8>, title: &str) {
    out.extend_from_slice(format!("\x1b]2;{title}\x07").as_bytes());
}

/// Forward mode changes to the host terminal so it encodes input correctly
/// (cursor keys, mouse, paste). alt_screen is deliberately NOT forwarded:
/// the client owns its own alt screen; it's tracked only as a prediction
/// guard. reverse_colors is display state the row payloads don't carry.
fn emit_mode_diff(out: &mut Vec<u8>, old: &Modes, new: &Modes) {
    let forwarded: [(bool, bool, u16); 13] = [
        (old.cursor_keys_app, new.cursor_keys_app, 1),
        (old.reverse_colors, new.reverse_colors, 5),
        (old.mouse_x10, new.mouse_x10, 9),
        (old.keypad_app, new.keypad_app, 66),
        (old.mouse_normal, new.mouse_normal, 1000),
        (old.mouse_button, new.mouse_button, 1002),
        (old.mouse_any, new.mouse_any, 1003),
        (old.focus_events, new.focus_events, 1004),
        (old.mouse_utf8, new.mouse_utf8, 1005),
        (old.mouse_sgr, new.mouse_sgr, 1006),
        (old.mouse_urxvt, new.mouse_urxvt, 1015),
        (old.mouse_sgr_pixels, new.mouse_sgr_pixels, 1016),
        (old.bracketed_paste, new.bracketed_paste, 2004),
    ];
    for (was, is, n) in forwarded {
        if was != is {
            let hl = if is { 'h' } else { 'l' };
            out.extend_from_slice(format!("\x1b[?{n}{hl}").as_bytes());
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::proto::{CursorState, ObjUpdate};

    /// A server-side terminal that produces snapshots/updates the way
    /// ghosh-server does.
    struct FakeServer {
        term: ghosh_vt::Terminal,
        gen: u64,
    }

    impl FakeServer {
        fn new() -> Self {
            Self { term: ghosh_vt::Terminal::new(80, 24).unwrap(), gen: 0 }
        }

        fn write(&mut self, bytes: &[u8]) -> Vec<u16> {
            self.term.write(bytes);
            self.gen += 1;
            self.term.take_dirty_rows().unwrap()
        }

        fn snapshot(&self) -> Snapshot {
            Snapshot {
                gen: self.gen,
                input_seq: 0,
                cols: self.term.cols(),
                rows: self.term.rows(),
                cursor: CursorState { x: 0, y: 0, visible: true },
                vt: self.term.snapshot_vt().unwrap(),
                title: self.term.title().unwrap(),
                modes: Modes::default(),
                scrollback: Vec::new(),
            }
        }

        fn row_update(&self, rows: &[u16]) -> Update {
            Update {
                gen: self.gen,
                input_seq: 0,
                cursor: CursorState { x: 0, y: 0, visible: true },
                objs: rows
                    .iter()
                    .map(|&r| ObjUpdate {
                        id: ObjId::Row(r),
                        gen: self.gen,
                        payload: self.term.row_vt(r).unwrap(),
                    })
                    .collect(),
            }
        }

        fn obj_update(&self, id: ObjId, gen: u64, payload: Vec<u8>) -> Update {
            Update {
                gen: self.gen,
                input_seq: 0,
                cursor: CursorState { x: 0, y: 0, visible: true },
                objs: vec![ObjUpdate { id, gen, payload }],
            }
        }
    }

    fn attach(server: &FakeServer) -> Replica {
        let mut r = Replica::new(80, 24).unwrap();
        r.apply_snapshot(&server.snapshot()).unwrap();
        r
    }

    #[test]
    fn replica_converges_with_server_through_updates() {
        let mut server = FakeServer::new();
        server.write(b"$ hello\r\n");
        let mut replica = attach(&server);

        let dirty = server.write(b"$ echo more\r\nmore\r\n");
        let o = replica.apply_update(&server.row_update(&dirty)).unwrap();

        assert!(!o.out.is_empty());
        assert_eq!(o.acks.len(), dirty.len());
        assert_eq!(o.touched_rows, dirty, "touched_rows mirrors what the update repainted");
        for y in 0..24 {
            assert_eq!(
                replica.term.row_text(y).unwrap(),
                server.term.row_text(y).unwrap(),
                "row {y} diverged"
            );
        }
    }

    #[test]
    fn rendered_output_comes_from_replica_and_matches_payload() {
        let mut server = FakeServer::new();
        server.write(b"first line");
        let mut replica = attach(&server);

        let dirty = server.write(b"\x1b[1;1Hreplaced");
        let o = replica.apply_update(&server.row_update(&dirty)).unwrap();
        // row_vt is a fixed point: replica render == server payload bytes.
        let expected: Vec<u8> =
            dirty.iter().flat_map(|&r| server.term.row_vt(r).unwrap()).collect();
        assert_eq!(o.out, expected);
    }

    #[test]
    fn stale_and_duplicate_updates_are_acked_but_not_rendered() {
        let mut server = FakeServer::new();
        server.write(b"content");
        let mut replica = attach(&server);

        let dirty = server.write(b"\x1b[1;1H\x1b[2Knewer");
        let update = server.row_update(&dirty);
        let o1 = replica.apply_update(&update).unwrap();
        assert!(!o1.out.is_empty());
        assert!(!o1.acks.is_empty());

        // Same update again (datagram duplicate / RTO re-send).
        let o2 = replica.apply_update(&update).unwrap();
        assert!(o2.out.is_empty(), "duplicate produced output: {:?}", String::from_utf8_lossy(&o2.out));
        assert!(o2.touched_rows.is_empty());
        assert_eq!(o2.acks, o1.acks, "duplicates still acked");

        // Older generation than the snapshot.
        let stale = server.obj_update(ObjId::Row(0), 0, b"\x1b[1;1Hstale".to_vec());
        let o3 = replica.apply_update(&stale).unwrap();
        assert!(o3.out.is_empty());
        assert_eq!(o3.acks, vec![(ObjId::Row(0), 0)]);
        assert_eq!(replica.term.row_text(0).unwrap(), "newer");
    }

    #[test]
    fn modes_update_emits_diff_and_tracks_alt_screen_silently() {
        let mut server = FakeServer::new();
        let mut replica = attach(&server);
        server.gen += 1;

        let new_modes = Modes {
            bracketed_paste: true,
            alt_screen: true,
            ..Modes::default()
        };
        let update = server.obj_update(
            ObjId::Modes,
            server.gen,
            postcard::to_allocvec(&new_modes).unwrap(),
        );
        let o = replica.apply_update(&update).unwrap();
        let text = String::from_utf8_lossy(&o.out);
        assert!(text.contains("\x1b[?2004h"), "bracketed paste forwarded: {text:?}");
        assert!(!text.contains("1049") && !text.contains("1047"), "alt screen not forwarded");
        assert!(replica.modes().alt_screen, "alt screen tracked for prediction");

        // Reset diff emits the matching 'l'.
        server.gen += 1;
        let update = server.obj_update(
            ObjId::Modes,
            server.gen,
            postcard::to_allocvec(&Modes::default()).unwrap(),
        );
        let o = replica.apply_update(&update).unwrap();
        assert!(String::from_utf8_lossy(&o.out).contains("\x1b[?2004l"));
        assert!(!replica.modes().alt_screen);
    }

    /// All forwarded modes flipped at once should emit ONE diff frame with
    /// every set transition, in canonical order, and nothing else.
    #[test]
    fn modes_diff_emits_only_changed_modes() {
        let mut server = FakeServer::new();
        let mut replica = attach(&server);
        server.gen += 1;

        // Just one mode changes.
        let modes = Modes { mouse_sgr: true, ..Modes::default() };
        let payload = postcard::to_allocvec(&modes).unwrap();
        let o = replica
            .apply_update(&server.obj_update(ObjId::Modes, server.gen, payload))
            .unwrap();
        assert_eq!(o.out, b"\x1b[?1006h", "only the one transition was forwarded");

        // Identical modes again => empty diff (still acked).
        server.gen += 1;
        let payload = postcard::to_allocvec(&modes).unwrap();
        let o = replica
            .apply_update(&server.obj_update(ObjId::Modes, server.gen, payload))
            .unwrap();
        assert!(o.out.is_empty(), "no transitions => no SGR; got {:?}", o.out);
    }

    #[test]
    fn modes_alt_screen_only_change_emits_nothing_but_tracks_state() {
        let mut server = FakeServer::new();
        let mut replica = attach(&server);
        server.gen += 1;

        let modes = Modes { alt_screen: true, ..Modes::default() };
        let payload = postcard::to_allocvec(&modes).unwrap();
        let o = replica
            .apply_update(&server.obj_update(ObjId::Modes, server.gen, payload))
            .unwrap();
        assert!(o.out.is_empty(), "alt_screen-only change must not touch host tty: {:?}", o.out);
        assert!(replica.modes().alt_screen);
    }

    #[test]
    fn modes_with_malformed_payload_is_ignored_but_acked() {
        let mut server = FakeServer::new();
        let mut replica = attach(&server);
        server.gen += 1;

        let o = replica
            .apply_update(&server.obj_update(ObjId::Modes, server.gen, vec![0xff; 8]))
            .unwrap();
        assert!(o.out.is_empty());
        assert_eq!(o.acks, vec![(ObjId::Modes, server.gen)]);
        assert_eq!(replica.modes(), Modes::default(), "modes unchanged on parse failure");
    }

    #[test]
    fn title_update_emits_osc2() {
        let mut server = FakeServer::new();
        let mut replica = attach(&server);
        server.gen += 1;

        let o = replica
            .apply_update(&server.obj_update(ObjId::Title, server.gen, b"my title".to_vec()))
            .unwrap();
        assert_eq!(o.out, b"\x1b]2;my title\x07");
    }

    /// Regression: a title set then cleared by the remote must clear in
    /// the host terminal too. Previous emit_title skipped empty strings.
    #[test]
    fn title_cleared_emits_empty_osc2() {
        let mut server = FakeServer::new();
        let mut replica = attach(&server);
        server.gen += 1;
        replica
            .apply_update(&server.obj_update(ObjId::Title, server.gen, b"foo".to_vec()))
            .unwrap();

        server.gen += 1;
        let o = replica
            .apply_update(&server.obj_update(ObjId::Title, server.gen, Vec::new()))
            .unwrap();
        assert_eq!(o.out, b"\x1b]2;\x07", "empty title clears via OSC 2");
    }

    #[test]
    fn snapshot_resets_applied_state_and_carries_title() {
        let mut server = FakeServer::new();
        server.write(b"\x1b]2;snap-title\x07some content");
        let mut replica = attach(&server);

        let out = replica.apply_snapshot(&server.snapshot()).unwrap();
        let text = String::from_utf8_lossy(&out);
        assert!(text.starts_with("\x1b[0m\x1b[2J\x1b[H"));
        assert!(text.contains("\x1b]2;snap-title\x07"));
        assert_eq!(replica.term.row_text(0).unwrap(), "some content");

        // Updates at or below the snapshot gen are stale now.
        let stale = server.obj_update(ObjId::Row(0), server.gen, b"\x1b[1;1Hx".to_vec());
        let o = replica.apply_update(&stale).unwrap();
        assert!(o.out.is_empty());
    }

    #[test]
    fn snapshot_with_scrollback_dumps_before_grid_repaint() {
        let mut server = FakeServer::new();
        server.write(b"live");
        let mut snap = server.snapshot();
        snap.scrollback = b"older line\n".to_vec();

        let mut replica = Replica::new(80, 24).unwrap();
        let out = replica.apply_snapshot(&snap).unwrap();
        let text = String::from_utf8_lossy(&out);
        let scroll_at = text.find("older line").expect("scrollback present");
        let clear_at = text.find("\x1b[2J").expect("clear present");
        assert!(scroll_at < clear_at, "scrollback must precede screen clear: {text:?}");
        assert!(text.contains("\x1b[?1049l"), "left alt-screen for dump");
        assert!(text.contains("\x1b[?1049h"), "re-entered alt-screen after dump");
    }

    #[test]
    fn snapshot_with_empty_scrollback_skips_alt_screen_dance() {
        let mut server = FakeServer::new();
        server.write(b"live");
        let mut replica = Replica::new(80, 24).unwrap();
        let out = replica.apply_snapshot(&server.snapshot()).unwrap();
        let text = String::from_utf8_lossy(&out);
        assert!(!text.contains("\x1b[?1049l"), "no alt-screen leave on empty scrollback");
        assert!(!text.contains("\x1b[?1049h"), "no alt-screen re-enter");
    }

    #[test]
    fn snapshot_shrinks_replica_grid() {
        // Reattach with a smaller terminal: the replica should resize, and
        // row payloads for nonexistent rows must not panic.
        let mut server = FakeServer::new();
        server.write(b"hi");
        let mut replica = Replica::new(80, 24).unwrap();
        let mut snap = server.snapshot();
        snap.cols = 40;
        snap.rows = 10;
        replica.apply_snapshot(&snap).unwrap();
        assert_eq!((replica.cols(), replica.rows()), (40, 10));

        // Stale-sized row update bounces off cleanly.
        server.gen += 1;
        let o = replica
            .apply_update(&server.obj_update(ObjId::Row(20), server.gen, vec![]))
            .unwrap();
        assert_eq!(o.acks, vec![(ObjId::Row(20), server.gen)]);
        assert!(o.touched_rows.is_empty());
    }

    #[test]
    fn out_of_range_row_after_resize_is_skipped() {
        let mut server = FakeServer::new();
        server.write(b"hello");
        let mut replica = attach(&server);

        replica.resize(80, 10).unwrap();
        let _ = replica.term.take_dirty_rows().unwrap();
        server.gen += 1;
        let update = server.obj_update(ObjId::Row(20), server.gen, b"\x1b[21;1Hghost".to_vec());
        let o = replica.apply_update(&update).unwrap();
        assert!(o.out.is_empty());
        assert_eq!(o.acks, vec![(ObjId::Row(20), server.gen)], "still acked");
    }

    #[test]
    fn cell_char_reads_replica_cells() {
        let mut server = FakeServer::new();
        server.write(b"ab cd");
        let replica = attach(&server);
        assert_eq!(replica.cell_char(0, 0).unwrap(), 'a');
        assert_eq!(replica.cell_char(2, 0).unwrap(), ' ');
        assert_eq!(replica.cell_char(4, 0).unwrap(), 'd');
        assert_eq!(replica.cell_char(79, 0).unwrap(), ' ', "beyond line end is blank");
        assert_eq!(replica.cell_char(0, 23).unwrap(), ' ', "empty row is blank");
    }

    /// Multi-object update arriving out of canonical order should still
    /// apply cleanly: Row, Modes, Title in a single Update.
    #[test]
    fn multi_object_update_applies_all() {
        let mut server = FakeServer::new();
        let mut replica = attach(&server);
        server.gen += 1;
        let modes_payload = postcard::to_allocvec(&Modes {
            bracketed_paste: true,
            ..Modes::default()
        })
        .unwrap();
        server.term.write(b"$ x");
        let dirty = server.term.take_dirty_rows().unwrap();
        let update = Update {
            gen: server.gen,
            input_seq: 0,
            cursor: CursorState { x: 0, y: 0, visible: true },
            objs: vec![
                ObjUpdate { id: ObjId::Title, gen: server.gen, payload: b"t".to_vec() },
                ObjUpdate { id: ObjId::Row(dirty[0]), gen: server.gen,
                            payload: server.term.row_vt(dirty[0]).unwrap() },
                ObjUpdate { id: ObjId::Modes, gen: server.gen, payload: modes_payload },
            ],
        };
        let o = replica.apply_update(&update).unwrap();
        let text = String::from_utf8_lossy(&o.out);
        assert!(text.contains("\x1b]2;t\x07"));
        assert!(text.contains("\x1b[?2004h"));
        assert!(replica.modes().bracketed_paste);
        assert!(replica.term.row_text(dirty[0]).unwrap().contains("$ x"));
        assert_eq!(o.acks.len(), 3);
    }
}
