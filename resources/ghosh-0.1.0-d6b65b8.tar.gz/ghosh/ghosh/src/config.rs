//! Minimal `~/.ghosh/config` reader. Tiny INI-ish format, no dependency.
//!
//! ```text
//! # comments and blank lines ignored
//! [mike@mikes-macbook-pro]
//! server_cmd = /Users/mike/.local/bin/ghosh-server
//!
//! [defaults]
//! server_cmd = ghosh-server
//! ssh        = ssh -o ConnectTimeout=8
//! ```
//!
//! Lookups fall back to a `[defaults]` section, then to env vars, then to
//! built-in defaults. Unknown keys are silently ignored so adding new
//! options later doesn't break old configs.
//!
//! Designed for ergonomic daily use: drop the path to your remote
//! ghosh-server in once, never type `GHOSH_SERVER_CMD=...` again.

use std::collections::HashMap;
use std::path::Path;

#[derive(Debug, Default, Clone)]
pub struct Config {
    sections: HashMap<String, HashMap<String, String>>,
}

impl Config {
    /// Parse a config file. Missing file is not an error — empty config.
    pub fn load(path: &Path) -> Self {
        std::fs::read_to_string(path)
            .ok()
            .map(|s| Self::parse(&s))
            .unwrap_or_default()
    }

    /// Get a value, checking the host-specific section first, then defaults.
    pub fn get(&self, host: &str, key: &str) -> Option<&str> {
        self.sections
            .get(host)
            .and_then(|s| s.get(key))
            .or_else(|| self.sections.get("defaults").and_then(|s| s.get(key)))
            .map(String::as_str)
    }

    fn parse(input: &str) -> Self {
        let mut cfg = Config::default();
        let mut current: Option<String> = None;
        for raw in input.lines() {
            let line = raw.split('#').next().unwrap_or("").trim();
            if line.is_empty() {
                continue;
            }
            if let Some(rest) = line.strip_prefix('[').and_then(|r| r.strip_suffix(']')) {
                current = Some(rest.trim().to_string());
                cfg.sections.entry(rest.trim().to_string()).or_default();
                continue;
            }
            if let Some((k, v)) = line.split_once('=') {
                if let Some(section) = &current {
                    cfg.sections
                        .entry(section.clone())
                        .or_default()
                        .insert(k.trim().to_string(), v.trim().to_string());
                }
                // Keys outside any section silently ignored — keeps the
                // parser dumb and the config schema explicit.
            }
        }
        cfg
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn missing_file_is_empty_config() {
        let cfg = Config::load(Path::new("/no/such/path/ever"));
        assert!(cfg.get("any", "any").is_none());
    }

    #[test]
    fn host_section_overrides_defaults() {
        let cfg = Config::parse(
            r#"
            [defaults]
            server_cmd = ghosh-server

            [mike@laptop]
            server_cmd = /Users/mike/.local/bin/ghosh-server
            "#,
        );
        assert_eq!(cfg.get("mike@laptop", "server_cmd"), Some("/Users/mike/.local/bin/ghosh-server"));
        assert_eq!(cfg.get("other@host", "server_cmd"), Some("ghosh-server"));
    }

    #[test]
    fn comments_and_blank_lines_ignored() {
        let cfg = Config::parse(
            r#"
            # comment header
            [host]
              # indented comment
            key=value  # trailing comment
            "#,
        );
        assert_eq!(cfg.get("host", "key"), Some("value"));
    }

    #[test]
    fn unknown_keys_silently_ignored() {
        // Old configs with keys we no longer recognize must not panic;
        // the absence of a known key just yields None.
        let cfg = Config::parse("[host]\nfoo = bar\n");
        assert!(cfg.get("host", "server_cmd").is_none());
        // But the foo key IS stored — Config is dumb storage.
        assert_eq!(cfg.get("host", "foo"), Some("bar"));
    }

    #[test]
    fn keys_outside_section_are_dropped() {
        let cfg = Config::parse("orphan = value\n[s]\nk = v\n");
        assert_eq!(cfg.get("s", "k"), Some("v"));
        assert!(cfg.get("", "orphan").is_none());
    }

    #[test]
    fn whitespace_around_keys_and_values_trimmed() {
        let cfg = Config::parse("[s]\n  key  =   value  \n");
        assert_eq!(cfg.get("s", "key"), Some("value"));
    }

    #[test]
    fn equals_in_value_preserved_after_first_split() {
        // A value like a shell command with `=` should survive intact past
        // the first `=` (split_once stops at the first).
        let cfg = Config::parse("[s]\ncmd = env A=1 B=2 prog\n");
        assert_eq!(cfg.get("s", "cmd"), Some("env A=1 B=2 prog"));
    }

    #[test]
    fn host_section_without_defaults_falls_back_to_none() {
        let cfg = Config::parse("[mike@host]\nserver_cmd = x\n");
        assert_eq!(cfg.get("mike@host", "server_cmd"), Some("x"));
        assert!(cfg.get("other", "server_cmd").is_none());
    }
}
