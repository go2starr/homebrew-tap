//! Server-side object sync tracker for one attached client.
//!
//! Tracks, per object: the generation it was last modified at (`obj_gen`),
//! the generation last sent to the client, and the generation the client
//! acked. An object needs sending when acked < obj_gen and it either hasn't
//! been sent at obj_gen yet or the send has gone unacked past the RTO.

use std::collections::HashMap;
use std::time::{Duration, Instant};

use crate::proto::ObjId;

#[derive(Debug, Clone, Copy, Default)]
struct ObjState {
    obj_gen: u64,
    acked: u64,
    sent: u64,
    sent_at: Option<Instant>,
}

#[derive(Default)]
pub struct ObjectSync {
    objs: HashMap<ObjId, ObjState>,
}

impl ObjectSync {
    pub fn new() -> Self {
        Self::default()
    }

    /// An object changed at `gen`.
    pub fn mark_dirty(&mut self, id: ObjId, gen: u64) {
        self.objs.entry(id).or_default().obj_gen = gen;
    }

    /// Resize the row space; every row becomes dirty at `gen`. Non-row
    /// objects are unaffected.
    pub fn resize(&mut self, num_rows: u16, gen: u64) {
        self.objs.retain(|id, _| !matches!(id, ObjId::Row(r) if *r >= num_rows));
        for row in 0..num_rows {
            self.objs.insert(ObjId::Row(row), ObjState { obj_gen: gen, ..Default::default() });
        }
    }

    /// Client (re)attached and was synced with a snapshot at `gen`:
    /// everything up to `gen` is known, nothing is in flight.
    pub fn attached_at(&mut self, gen: u64) {
        for s in self.objs.values_mut() {
            s.acked = gen;
            s.sent = 0;
            s.sent_at = None;
        }
    }

    pub fn ack(&mut self, id: ObjId, gen: u64) {
        if let Some(s) = self.objs.get_mut(&id) {
            s.acked = s.acked.max(gen);
        }
    }

    /// Objects that need (re)sending now, in stable order.
    pub fn pending(&self, now: Instant, rto: Duration) -> Vec<ObjId> {
        let mut out: Vec<ObjId> = self
            .objs
            .iter()
            .filter(|(_, s)| {
                s.acked < s.obj_gen
                    && (s.sent < s.obj_gen
                        || s.sent_at.is_none_or(|t| now.duration_since(t) >= rto))
            })
            .map(|(id, _)| *id)
            .collect();
        out.sort();
        out
    }

    pub fn on_sent(&mut self, id: ObjId, gen: u64, now: Instant) {
        if let Some(s) = self.objs.get_mut(&id) {
            s.sent = gen;
            s.sent_at = Some(now);
        }
    }

    pub fn obj_gen(&self, id: ObjId) -> u64 {
        self.objs.get(&id).map_or(0, |s| s.obj_gen)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const RTO: Duration = Duration::from_millis(100);

    #[test]
    fn dirty_obj_becomes_pending_until_acked() {
        let mut s = ObjectSync::new();
        let now = Instant::now();
        assert!(s.pending(now, RTO).is_empty());

        s.mark_dirty(ObjId::Row(3), 1);
        assert_eq!(s.pending(now, RTO), vec![ObjId::Row(3)]);

        s.on_sent(ObjId::Row(3), 1, now);
        assert!(s.pending(now, RTO).is_empty(), "in flight, not re-sent yet");

        // Unacked past RTO: re-send.
        assert_eq!(s.pending(now + RTO * 2, RTO), vec![ObjId::Row(3)]);

        s.ack(ObjId::Row(3), 1);
        assert!(s.pending(now + RTO * 2, RTO).is_empty());
    }

    #[test]
    fn newer_dirt_resends_immediately() {
        let mut s = ObjectSync::new();
        let now = Instant::now();
        s.mark_dirty(ObjId::Row(0), 1);
        s.on_sent(ObjId::Row(0), 1, now);
        s.mark_dirty(ObjId::Row(0), 2);
        assert_eq!(s.pending(now, RTO), vec![ObjId::Row(0)], "newer gen bypasses in-flight wait");
    }

    #[test]
    fn stale_ack_does_not_regress() {
        let mut s = ObjectSync::new();
        s.mark_dirty(ObjId::Row(0), 5);
        s.ack(ObjId::Row(0), 5);
        s.ack(ObjId::Row(0), 3);
        assert!(s.pending(Instant::now(), RTO).is_empty());
    }

    #[test]
    fn attach_snapshot_covers_prior_dirt() {
        let mut s = ObjectSync::new();
        s.mark_dirty(ObjId::Row(1), 4);
        s.mark_dirty(ObjId::Modes, 4);
        s.mark_dirty(ObjId::Row(2), 6);
        s.attached_at(5);
        let pending = s.pending(Instant::now(), RTO);
        assert_eq!(pending, vec![ObjId::Row(2)], "only post-snapshot dirt pending");
    }

    #[test]
    fn resize_dirties_rows_but_not_modes_or_title() {
        let mut s = ObjectSync::new();
        s.mark_dirty(ObjId::Modes, 3);
        s.ack(ObjId::Modes, 3);
        s.mark_dirty(ObjId::Row(30), 3);
        s.resize(24, 4);

        let pending = s.pending(Instant::now(), RTO);
        assert_eq!(pending.len(), 24, "all surviving rows dirty: {pending:?}");
        assert!(!pending.contains(&ObjId::Modes));
        assert!(!pending.contains(&ObjId::Row(30)), "out-of-range row dropped");
    }

    #[test]
    fn modes_and_title_sync_like_rows() {
        let mut s = ObjectSync::new();
        let now = Instant::now();
        s.mark_dirty(ObjId::Title, 2);
        s.mark_dirty(ObjId::Modes, 3);
        assert_eq!(s.pending(now, RTO), vec![ObjId::Modes, ObjId::Title]);

        s.on_sent(ObjId::Modes, 3, now);
        s.on_sent(ObjId::Title, 2, now);
        s.ack(ObjId::Title, 2);
        assert!(s.pending(now, RTO).is_empty());
        assert_eq!(s.pending(now + RTO * 2, RTO), vec![ObjId::Modes]);
    }

    #[test]
    fn resize_grow_marks_new_rows_dirty() {
        let mut s = ObjectSync::new();
        s.resize(5, 1);
        let pending = s.pending(Instant::now(), RTO);
        assert_eq!(pending.len(), 5);
        // Acked rows + grow: only the newly-introduced rows should be dirty.
        for r in 0..5 {
            s.on_sent(ObjId::Row(r), 1, Instant::now());
            s.ack(ObjId::Row(r), 1);
        }
        assert!(s.pending(Instant::now(), RTO).is_empty());

        s.resize(8, 2);
        let pending = s.pending(Instant::now(), RTO);
        assert_eq!(pending.len(), 8, "every row dirty at the resize gen: {pending:?}");
    }

    #[test]
    fn attached_at_clears_in_flight_state() {
        // Reattach mid-flight: any prior sent state is meaningless
        // (it was on a dead connection). The snapshot's gen covers it.
        let mut s = ObjectSync::new();
        let t0 = Instant::now();
        s.mark_dirty(ObjId::Row(0), 5);
        s.on_sent(ObjId::Row(0), 5, t0);
        assert!(s.pending(t0, RTO).is_empty(), "in flight, no resend");
        s.attached_at(5);
        // After attach, nothing pending and no stale sent_at to time out.
        assert!(s.pending(t0 + RTO * 2, RTO).is_empty());
        // Future dirt requires a fresh sent.
        s.mark_dirty(ObjId::Row(0), 6);
        assert_eq!(s.pending(t0, RTO), vec![ObjId::Row(0)]);
    }

    #[test]
    fn pending_returns_stable_sorted_order() {
        let mut s = ObjectSync::new();
        s.mark_dirty(ObjId::Title, 1);
        s.mark_dirty(ObjId::Row(10), 1);
        s.mark_dirty(ObjId::Modes, 1);
        s.mark_dirty(ObjId::Row(2), 1);
        // Rows first (by index), then Modes, then Title.
        let p = s.pending(Instant::now(), RTO);
        assert_eq!(p, vec![ObjId::Row(2), ObjId::Row(10), ObjId::Modes, ObjId::Title]);
    }

    #[test]
    fn obj_gen_zero_for_unknown_obj() {
        let s = ObjectSync::new();
        assert_eq!(s.obj_gen(ObjId::Row(0)), 0);
        assert_eq!(s.obj_gen(ObjId::Modes), 0);
    }

    #[test]
    fn ack_for_unknown_obj_is_noop() {
        let mut s = ObjectSync::new();
        s.ack(ObjId::Row(0), 5);
        // No panic, no entry created.
        assert_eq!(s.obj_gen(ObjId::Row(0)), 0);
    }
}
