pub mod config;
pub mod predict;
pub mod proto;
pub mod replica;
pub mod sync;

pub const ALPN: &[u8] = b"ghosh/0";

use std::path::PathBuf;

/// Demo-mode rendezvous: server writes cert + addr here, client reads them.
/// Replaced by ssh bootstrap later.
pub fn demo_dir() -> PathBuf {
    let home = std::env::var("HOME").expect("HOME not set");
    PathBuf::from(home).join(".ghosh")
}
