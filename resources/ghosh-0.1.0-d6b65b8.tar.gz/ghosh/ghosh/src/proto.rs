//! ghosh wire protocol: postcard-encoded messages.
//!
//! Control stream (bidi, reliable): length-prefixed `ClientMsg` / `ServerMsg`.
//! Server uni streams: one `Snapshot` per stream.
//! Datagrams: `Update` (S→C) and `Ack` (C→S), one message per datagram.

use anyhow::{bail, Context, Result};
use serde::{Deserialize, Serialize};

pub const PROTO_VERSION: u32 = 2;

/// Independently-versioned sync object. Latest generation wins.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
pub enum ObjId {
    Row(u16),
    /// Payload: postcard-encoded `Modes`.
    Modes,
    /// Payload: UTF-8 title bytes.
    Title,
}

/// Terminal modes the client must mirror. Structured (not VT passthrough)
/// because the client routes them differently: input-encoding modes are
/// forwarded to the host terminal, while alt_screen must NOT be (the client
/// owns its own alt screen) and is tracked only for prediction guards.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct Modes {
    pub alt_screen: bool,
    pub cursor_keys_app: bool, // DECCKM (?1)
    pub keypad_app: bool,      // DECNKM (?66)
    pub reverse_colors: bool,  // DECSCNM (?5)
    pub bracketed_paste: bool, // ?2004
    pub focus_events: bool,    // ?1004
    pub mouse_x10: bool,       // ?9
    pub mouse_normal: bool,    // ?1000
    pub mouse_button: bool,    // ?1002
    pub mouse_any: bool,       // ?1003
    pub mouse_utf8: bool,      // ?1005
    pub mouse_sgr: bool,       // ?1006
    pub mouse_urxvt: bool,     // ?1015
    pub mouse_sgr_pixels: bool, // ?1016
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct CursorState {
    pub x: u16,
    pub y: u16,
    pub visible: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ClientMsg {
    Hello { proto: u32, token: Vec<u8>, cols: u16, rows: u16 },
    Input { seq: u64, bytes: Vec<u8> },
    Resize { cols: u16, rows: u16 },
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ServerMsg {
    HelloAck { gen: u64 },
    Exit { status: u32 },
}

/// One state update datagram. Idempotent: every object payload is a
/// self-contained repaint, and `cursor` is always the latest server state.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Update {
    pub gen: u64,
    /// Last client input seq the server had applied when this was sent.
    pub input_seq: u64,
    pub cursor: CursorState,
    pub objs: Vec<ObjUpdate>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ObjUpdate {
    pub id: ObjId,
    pub gen: u64,
    pub payload: Vec<u8>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Ack {
    pub acks: Vec<(ObjId, u64)>,
}

/// Frames carried on server-initiated uni streams.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum UniFrame {
    Snapshot(Snapshot),
    /// An update too large for a datagram; semantics identical to the
    /// datagram path.
    Update(Update),
}

/// Full-state resync, sent on its own uni stream at attach/reattach.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Snapshot {
    pub gen: u64,
    pub input_seq: u64,
    pub cols: u16,
    pub rows: u16,
    pub cursor: CursorState,
    pub vt: Vec<u8>,
    pub title: String,
    pub modes: Modes,
    /// Scrollback lines pushed out of the live grid since the previous
    /// attach. Empty on first attach. Applied BEFORE the live grid so the
    /// host terminal's natural scrollback buffer absorbs them.
    pub scrollback: Vec<u8>,
}

const MAX_FRAME: u32 = 1024 * 1024;

pub async fn write_frame<T: Serialize>(stream: &mut quinn::SendStream, msg: &T) -> Result<()> {
    let bytes = postcard::to_allocvec(msg)?;
    let len = u32::try_from(bytes.len())?;
    stream.write_all(&len.to_le_bytes()).await?;
    stream.write_all(&bytes).await?;
    Ok(())
}

pub async fn read_frame<T: for<'de> Deserialize<'de>>(
    stream: &mut quinn::RecvStream,
) -> Result<T> {
    let mut len_buf = [0u8; 4];
    stream
        .read_exact(&mut len_buf)
        .await
        .context("read frame length")?;
    let len = u32::from_le_bytes(len_buf);
    if len > MAX_FRAME {
        bail!("frame too large: {len}");
    }
    let mut buf = vec![0u8; len as usize];
    stream.read_exact(&mut buf).await.context("read frame body")?;
    Ok(postcard::from_bytes(&buf)?)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn update_roundtrip() {
        let update = Update {
            gen: 42,
            input_seq: 7,
            cursor: CursorState { x: 3, y: 5, visible: true },
            objs: vec![ObjUpdate {
                id: ObjId::Row(5),
                gen: 42,
                payload: b"\x1b[6;1Hhello".to_vec(),
            }],
        };
        let bytes = postcard::to_allocvec(&update).unwrap();
        let back: Update = postcard::from_bytes(&bytes).unwrap();
        assert_eq!(back.gen, 42);
        assert_eq!(back.objs[0].id, ObjId::Row(5));
    }

    #[test]
    fn update_with_all_obj_kinds_roundtrips() {
        let update = Update {
            gen: 1,
            input_seq: 0,
            cursor: CursorState { x: 0, y: 0, visible: false },
            objs: vec![
                ObjUpdate { id: ObjId::Row(0), gen: 1, payload: b"row".to_vec() },
                ObjUpdate { id: ObjId::Modes, gen: 1, payload: b"m".to_vec() },
                ObjUpdate { id: ObjId::Title, gen: 1, payload: b"t".to_vec() },
            ],
        };
        let bytes = postcard::to_allocvec(&update).unwrap();
        let back: Update = postcard::from_bytes(&bytes).unwrap();
        assert_eq!(back.objs.len(), 3);
        assert_eq!(back.objs[0].id, ObjId::Row(0));
        assert_eq!(back.objs[1].id, ObjId::Modes);
        assert_eq!(back.objs[2].id, ObjId::Title);
    }

    #[test]
    fn modes_roundtrip() {
        let m = Modes {
            alt_screen: true,
            cursor_keys_app: true,
            bracketed_paste: true,
            mouse_sgr: true,
            ..Modes::default()
        };
        let bytes = postcard::to_allocvec(&m).unwrap();
        let back: Modes = postcard::from_bytes(&bytes).unwrap();
        assert_eq!(back, m);
    }

    #[test]
    fn snapshot_roundtrip_carries_modes_and_title() {
        let snap = Snapshot {
            gen: 9,
            input_seq: 3,
            cols: 80,
            rows: 24,
            cursor: CursorState { x: 1, y: 2, visible: true },
            vt: b"\x1b[2J".to_vec(),
            title: "hello".to_string(),
            modes: Modes { bracketed_paste: true, ..Modes::default() },
            scrollback: b"old line\r\n".to_vec(),
        };
        let bytes = postcard::to_allocvec(&snap).unwrap();
        let back: Snapshot = postcard::from_bytes(&bytes).unwrap();
        assert_eq!(back.title, "hello");
        assert!(back.modes.bracketed_paste);
        assert_eq!(back.cols, 80);
        assert_eq!(back.scrollback, b"old line\r\n");
    }

    #[test]
    fn obj_id_orders_rows_before_modes_before_title() {
        // ObjectSync iterates with sort(), and prediction relies on row
        // payloads being applied before modes/title in a multi-object update.
        let mut v = vec![ObjId::Title, ObjId::Modes, ObjId::Row(5), ObjId::Row(2)];
        v.sort();
        assert_eq!(v, vec![ObjId::Row(2), ObjId::Row(5), ObjId::Modes, ObjId::Title]);
    }

    #[test]
    fn ack_roundtrip_preserves_obj_ids() {
        let ack = Ack { acks: vec![
            (ObjId::Row(0), 1),
            (ObjId::Modes, 2),
            (ObjId::Title, 3),
        ] };
        let bytes = postcard::to_allocvec(&ack).unwrap();
        let back: Ack = postcard::from_bytes(&bytes).unwrap();
        assert_eq!(back.acks, ack.acks);
    }

    #[tokio::test]
    async fn frame_streaming_roundtrip() {
        use tokio::io::AsyncReadExt;
        // Hand-roll a length-prefixed frame and decode via read_frame.
        let payload = ClientMsg::Input { seq: 9, bytes: b"hi".to_vec() };
        let body = postcard::to_allocvec(&payload).unwrap();
        let mut wire = (body.len() as u32).to_le_bytes().to_vec();
        wire.extend_from_slice(&body);

        let (mut tx, rx) = tokio::io::duplex(1024);
        tokio::io::AsyncWriteExt::write_all(&mut tx, &wire).await.unwrap();
        drop(tx);
        let mut buf = Vec::new();
        tokio::io::BufReader::new(rx).read_to_end(&mut buf).await.unwrap();
        let len = u32::from_le_bytes(buf[..4].try_into().unwrap()) as usize;
        let back: ClientMsg = postcard::from_bytes(&buf[4..4+len]).unwrap();
        match back {
            ClientMsg::Input { seq, bytes } => {
                assert_eq!(seq, 9);
                assert_eq!(bytes, b"hi");
            }
            other => panic!("expected Input, got {other:?}"),
        }
    }
}
